var er = Object.defineProperty;
var tr = (e, t, r) => t in e ? er(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var V = (e, t, r) => tr(e, typeof t != "symbol" ? t + "" : t, r);
var Ee = { exports: {} }, rr = Ee.exports, nt;
function nr() {
  return nt || (nt = 1, function(e, t) {
    (function(r, n) {
      n(e);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : rr, function(r) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        r.exports = globalThis.browser;
      else {
        const n = "The message port closed before a response was received.", o = (s) => {
          const a = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(a).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class i extends WeakMap {
            constructor(p, v = void 0) {
              super(v), this.createItem = p;
            }
            get(p) {
              return this.has(p) || this.set(p, this.createItem(p)), super.get(p);
            }
          }
          const c = (f) => f && typeof f == "object" && typeof f.then == "function", l = (f, p) => (...v) => {
            s.runtime.lastError ? f.reject(new Error(s.runtime.lastError.message)) : p.singleCallbackArg || v.length <= 1 && p.singleCallbackArg !== !1 ? f.resolve(v[0]) : f.resolve(v);
          }, g = (f) => f == 1 ? "argument" : "arguments", m = (f, p) => function(I, ...N) {
            if (N.length < p.minArgs)
              throw new Error(`Expected at least ${p.minArgs} ${g(p.minArgs)} for ${f}(), got ${N.length}`);
            if (N.length > p.maxArgs)
              throw new Error(`Expected at most ${p.maxArgs} ${g(p.maxArgs)} for ${f}(), got ${N.length}`);
            return new Promise((B, J) => {
              if (p.fallbackToNoCallback)
                try {
                  I[f](...N, l({
                    resolve: B,
                    reject: J
                  }, p));
                } catch (_) {
                  console.warn(`${f} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, _), I[f](...N), p.fallbackToNoCallback = !1, p.noCallback = !0, B();
                }
              else p.noCallback ? (I[f](...N), B()) : I[f](...N, l({
                resolve: B,
                reject: J
              }, p));
            });
          }, b = (f, p, v) => new Proxy(p, {
            apply(I, N, B) {
              return v.call(N, f, ...B);
            }
          });
          let h = Function.call.bind(Object.prototype.hasOwnProperty);
          const y = (f, p = {}, v = {}) => {
            let I = /* @__PURE__ */ Object.create(null), N = {
              has(J, _) {
                return _ in f || _ in I;
              },
              get(J, _, W) {
                if (_ in I)
                  return I[_];
                if (!(_ in f))
                  return;
                let C = f[_];
                if (typeof C == "function")
                  if (typeof p[_] == "function")
                    C = b(f, f[_], p[_]);
                  else if (h(v, _)) {
                    let ce = m(_, v[_]);
                    C = b(f, f[_], ce);
                  } else
                    C = C.bind(f);
                else if (typeof C == "object" && C !== null && (h(p, _) || h(v, _)))
                  C = y(C, p[_], v[_]);
                else if (h(v, "*"))
                  C = y(C, p[_], v["*"]);
                else
                  return Object.defineProperty(I, _, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return f[_];
                    },
                    set(ce) {
                      f[_] = ce;
                    }
                  }), C;
                return I[_] = C, C;
              },
              set(J, _, W, C) {
                return _ in I ? I[_] = W : f[_] = W, !0;
              },
              defineProperty(J, _, W) {
                return Reflect.defineProperty(I, _, W);
              },
              deleteProperty(J, _) {
                return Reflect.deleteProperty(I, _);
              }
            }, B = Object.create(f);
            return new Proxy(B, N);
          }, O = (f) => ({
            addListener(p, v, ...I) {
              p.addListener(f.get(v), ...I);
            },
            hasListener(p, v) {
              return p.hasListener(f.get(v));
            },
            removeListener(p, v) {
              p.removeListener(f.get(v));
            }
          }), F = new i((f) => typeof f != "function" ? f : function(v) {
            const I = y(v, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            f(I);
          }), A = new i((f) => typeof f != "function" ? f : function(v, I, N) {
            let B = !1, J, _ = new Promise((be) => {
              J = function(Y) {
                B = !0, be(Y);
              };
            }), W;
            try {
              W = f(v, I, J);
            } catch (be) {
              W = Promise.reject(be);
            }
            const C = W !== !0 && c(W);
            if (W !== !0 && !C && !B)
              return !1;
            const ce = (be) => {
              be.then((Y) => {
                N(Y);
              }, (Y) => {
                let Re;
                Y && (Y instanceof Error || typeof Y.message == "string") ? Re = Y.message : Re = "An unexpected error occurred", N({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: Re
                });
              }).catch((Y) => {
                console.error("Failed to send onMessage rejected reply", Y);
              });
            };
            return ce(C ? W : _), !0;
          }), j = ({
            reject: f,
            resolve: p
          }, v) => {
            s.runtime.lastError ? s.runtime.lastError.message === n ? p() : f(new Error(s.runtime.lastError.message)) : v && v.__mozWebExtensionPolyfillReject__ ? f(new Error(v.message)) : p(v);
          }, U = (f, p, v, ...I) => {
            if (I.length < p.minArgs)
              throw new Error(`Expected at least ${p.minArgs} ${g(p.minArgs)} for ${f}(), got ${I.length}`);
            if (I.length > p.maxArgs)
              throw new Error(`Expected at most ${p.maxArgs} ${g(p.maxArgs)} for ${f}(), got ${I.length}`);
            return new Promise((N, B) => {
              const J = j.bind(null, {
                resolve: N,
                reject: B
              });
              I.push(J), v.sendMessage(...I);
            });
          }, q = {
            devtools: {
              network: {
                onRequestFinished: O(F)
              }
            },
            runtime: {
              onMessage: O(A),
              onMessageExternal: O(A),
              sendMessage: U.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: U.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, Q = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return a.privacy = {
            network: {
              "*": Q
            },
            services: {
              "*": Q
            },
            websites: {
              "*": Q
            }
          }, y(s, q, a);
        };
        r.exports = o(chrome);
      }
    });
  }(Ee)), Ee.exports;
}
nr();
var _e;
(function(e) {
  e.Local = "local", e.Sync = "sync", e.Managed = "managed", e.Session = "session";
})(_e || (_e = {}));
var Ue;
(function(e) {
  e.ExtensionPagesOnly = "TRUSTED_CONTEXTS", e.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(Ue || (Ue = {}));
const L = globalThis.chrome, ot = async (e, t) => {
  const r = (o) => typeof o == "function", n = (o) => (
    // Use ReturnType to infer the return type of the function and check if it's a Promise
    o instanceof Promise
  );
  return r(e) ? (n(e), e(t)) : e;
};
let st = !1;
const at = (e) => {
  if (L && !L.storage[e])
    throw new Error(`"storage" permission in manifest.ts: "storage ${e}" isn't defined`);
}, or = (e, t, r) => {
  var O, F;
  let n = null, o = !1, s = [];
  const a = (r == null ? void 0 : r.storageEnum) ?? _e.Local, i = ((O = r == null ? void 0 : r.serialization) == null ? void 0 : O.serialize) ?? ((A) => A), c = ((F = r == null ? void 0 : r.serialization) == null ? void 0 : F.deserialize) ?? ((A) => A);
  st === !1 && a === _e.Session && (r == null ? void 0 : r.sessionAccessForContentScripts) === !0 && (at(a), L == null || L.storage[a].setAccessLevel({
    accessLevel: Ue.ExtensionPagesAndContentScripts
  }).catch((A) => {
    console.error(A), console.error("Please call .setAccessLevel() into different context, like a background script.");
  }), st = !0);
  const l = async () => {
    at(a);
    const A = await (L == null ? void 0 : L.storage[a].get([e]));
    return A ? c(A[e]) ?? t : t;
  }, g = async (A) => {
    o || (n = await l()), n = await ot(A, n), await (L == null ? void 0 : L.storage[a].set({ [e]: i(n) })), h();
  }, m = (A) => (s = [...s, A], () => {
    s = s.filter((j) => j !== A);
  }), b = () => n, h = () => {
    s.forEach((A) => A());
  }, y = async (A) => {
    if (A[e] === void 0)
      return;
    const j = c(A[e].newValue);
    n !== j && (n = await ot(j, n), h());
  };
  return l().then((A) => {
    n = A, o = !0, h();
  }), L == null || L.storage[a].onChanged.addListener(y), {
    get: l,
    set: g,
    getSnapshot: b,
    subscribe: m
  };
};
function u(e, t, r) {
  function n(i, c) {
    var l;
    Object.defineProperty(i, "_zod", {
      value: i._zod ?? {},
      enumerable: !1
    }), (l = i._zod).traits ?? (l.traits = /* @__PURE__ */ new Set()), i._zod.traits.add(e), t(i, c);
    for (const g in a.prototype)
      g in i || Object.defineProperty(i, g, { value: a.prototype[g].bind(i) });
    i._zod.constr = a, i._zod.def = c;
  }
  const o = (r == null ? void 0 : r.Parent) ?? Object;
  class s extends o {
  }
  Object.defineProperty(s, "name", { value: e });
  function a(i) {
    var c;
    const l = r != null && r.Parent ? new s() : this;
    n(l, i), (c = l._zod).deferred ?? (c.deferred = []);
    for (const g of l._zod.deferred)
      g();
    return l;
  }
  return Object.defineProperty(a, "init", { value: n }), Object.defineProperty(a, Symbol.hasInstance, {
    value: (i) => {
      var c, l;
      return r != null && r.Parent && i instanceof r.Parent ? !0 : (l = (c = i == null ? void 0 : i._zod) == null ? void 0 : c.traits) == null ? void 0 : l.has(e);
    }
  }), Object.defineProperty(a, "name", { value: e }), a;
}
class de extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class Tt extends Error {
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}
const Zt = {};
function te(e) {
  return Zt;
}
function sr(e) {
  const t = Object.values(e).filter((n) => typeof n == "number");
  return Object.entries(e).filter(([n, o]) => t.indexOf(+n) === -1).map(([n, o]) => o);
}
function qe(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
function He(e) {
  return {
    get value() {
      {
        const t = e();
        return Object.defineProperty(this, "value", { value: t }), t;
      }
    }
  };
}
function Ke(e) {
  return e == null;
}
function Ye(e) {
  const t = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, r);
}
function ar(e, t) {
  const r = (e.toString().split(".")[1] || "").length, n = t.toString();
  let o = (n.split(".")[1] || "").length;
  if (o === 0 && /\d?e-\d?/.test(n)) {
    const c = n.match(/\d?e-(\d?)/);
    c != null && c[1] && (o = Number.parseInt(c[1]));
  }
  const s = r > o ? r : o, a = Number.parseInt(e.toFixed(s).replace(".", "")), i = Number.parseInt(t.toFixed(s).replace(".", ""));
  return a % i / 10 ** s;
}
const it = Symbol("evaluating");
function $(e, t, r) {
  let n;
  Object.defineProperty(e, t, {
    get() {
      if (n !== it)
        return n === void 0 && (n = it, n = r()), n;
    },
    set(o) {
      Object.defineProperty(e, t, {
        value: o
        // configurable: true,
      });
    },
    configurable: !0
  });
}
function ir(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
function ne(e, t, r) {
  Object.defineProperty(e, t, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function we(...e) {
  const t = {};
  for (const r of e) {
    const n = Object.getOwnPropertyDescriptors(r);
    Object.assign(t, n);
  }
  return Object.defineProperties({}, t);
}
function ct(e) {
  return JSON.stringify(e);
}
const St = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Ze(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
const cr = He(() => {
  var e;
  if (typeof navigator < "u" && ((e = navigator == null ? void 0 : navigator.userAgent) != null && e.includes("Cloudflare")))
    return !1;
  try {
    const t = Function;
    return new t(""), !0;
  } catch {
    return !1;
  }
});
function fe(e) {
  if (Ze(e) === !1)
    return !1;
  const t = e.constructor;
  if (t === void 0)
    return !0;
  const r = t.prototype;
  return !(Ze(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
function Ot(e) {
  return fe(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
}
const ur = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function Ne(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function oe(e, t, r) {
  const n = new e._zod.constr(t ?? e._zod.def);
  return (!t || r != null && r.parent) && (n._zod.parent = e), n;
}
function d(e) {
  const t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: () => t };
  if ((t == null ? void 0 : t.message) !== void 0) {
    if ((t == null ? void 0 : t.error) !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
}
function lr(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
const gr = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function dr(e, t) {
  const r = e._zod.def, n = we(e._zod.def, {
    get shape() {
      const o = {};
      for (const s in t) {
        if (!(s in r.shape))
          throw new Error(`Unrecognized key: "${s}"`);
        t[s] && (o[s] = r.shape[s]);
      }
      return ne(this, "shape", o), o;
    },
    checks: []
  });
  return oe(e, n);
}
function mr(e, t) {
  const r = e._zod.def, n = we(e._zod.def, {
    get shape() {
      const o = { ...e._zod.def.shape };
      for (const s in t) {
        if (!(s in r.shape))
          throw new Error(`Unrecognized key: "${s}"`);
        t[s] && delete o[s];
      }
      return ne(this, "shape", o), o;
    },
    checks: []
  });
  return oe(e, n);
}
function fr(e, t) {
  if (!fe(t))
    throw new Error("Invalid input to extend: expected a plain object");
  const r = e._zod.def.checks;
  if (r && r.length > 0)
    throw new Error("Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.");
  const o = we(e._zod.def, {
    get shape() {
      const s = { ...e._zod.def.shape, ...t };
      return ne(this, "shape", s), s;
    },
    checks: []
  });
  return oe(e, o);
}
function hr(e, t) {
  if (!fe(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  const r = {
    ...e._zod.def,
    get shape() {
      const n = { ...e._zod.def.shape, ...t };
      return ne(this, "shape", n), n;
    },
    checks: e._zod.def.checks
  };
  return oe(e, r);
}
function pr(e, t) {
  const r = we(e._zod.def, {
    get shape() {
      const n = { ...e._zod.def.shape, ...t._zod.def.shape };
      return ne(this, "shape", n), n;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: []
    // delete existing checks
  });
  return oe(e, r);
}
function wr(e, t, r) {
  const n = we(t._zod.def, {
    get shape() {
      const o = t._zod.def.shape, s = { ...o };
      if (r)
        for (const a in r) {
          if (!(a in o))
            throw new Error(`Unrecognized key: "${a}"`);
          r[a] && (s[a] = e ? new e({
            type: "optional",
            innerType: o[a]
          }) : o[a]);
        }
      else
        for (const a in o)
          s[a] = e ? new e({
            type: "optional",
            innerType: o[a]
          }) : o[a];
      return ne(this, "shape", s), s;
    },
    checks: []
  });
  return oe(t, n);
}
function br(e, t, r) {
  const n = we(t._zod.def, {
    get shape() {
      const o = t._zod.def.shape, s = { ...o };
      if (r)
        for (const a in r) {
          if (!(a in s))
            throw new Error(`Unrecognized key: "${a}"`);
          r[a] && (s[a] = new e({
            type: "nonoptional",
            innerType: o[a]
          }));
        }
      else
        for (const a in o)
          s[a] = new e({
            type: "nonoptional",
            innerType: o[a]
          });
      return ne(this, "shape", s), s;
    },
    checks: []
  });
  return oe(t, n);
}
function le(e, t = 0) {
  var r;
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (((r = e.issues[n]) == null ? void 0 : r.continue) !== !0)
      return !0;
  return !1;
}
function ge(e, t) {
  return t.map((r) => {
    var n;
    return (n = r).path ?? (n.path = []), r.path.unshift(e), r;
  });
}
function ye(e) {
  return typeof e == "string" ? e : e == null ? void 0 : e.message;
}
function re(e, t, r) {
  var o, s, a, i, c, l;
  const n = { ...e, path: e.path ?? [] };
  if (!e.message) {
    const g = ye((a = (s = (o = e.inst) == null ? void 0 : o._zod.def) == null ? void 0 : s.error) == null ? void 0 : a.call(s, e)) ?? ye((i = t == null ? void 0 : t.error) == null ? void 0 : i.call(t, e)) ?? ye((c = r.customError) == null ? void 0 : c.call(r, e)) ?? ye((l = r.localeError) == null ? void 0 : l.call(r, e)) ?? "Invalid input";
    n.message = g;
  }
  return delete n.inst, delete n.continue, t != null && t.reportInput || delete n.input, n;
}
function Xe(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function Ae(...e) {
  const [t, r, n] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: r,
    inst: n
  } : { ...t };
}
const Mt = (e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, qe, 2), Object.defineProperty(e, "toString", {
    value: () => e.message,
    enumerable: !1
  });
}, Pt = u("$ZodError", Mt), Ct = u("$ZodError", Mt, { Parent: Error });
function _r(e, t = (r) => r.message) {
  const r = {}, n = [];
  for (const o of e.issues)
    o.path.length > 0 ? (r[o.path[0]] = r[o.path[0]] || [], r[o.path[0]].push(t(o))) : n.push(t(o));
  return { formErrors: n, fieldErrors: r };
}
function Ar(e, t) {
  const r = t || function(s) {
    return s.message;
  }, n = { _errors: [] }, o = (s) => {
    for (const a of s.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((i) => o({ issues: i }));
      else if (a.code === "invalid_key")
        o({ issues: a.issues });
      else if (a.code === "invalid_element")
        o({ issues: a.issues });
      else if (a.path.length === 0)
        n._errors.push(r(a));
      else {
        let i = n, c = 0;
        for (; c < a.path.length; ) {
          const l = a.path[c];
          c === a.path.length - 1 ? (i[l] = i[l] || { _errors: [] }, i[l]._errors.push(r(a))) : i[l] = i[l] || { _errors: [] }, i = i[l], c++;
        }
      }
  };
  return o(e), n;
}
const Qe = (e) => (t, r, n, o) => {
  const s = n ? Object.assign(n, { async: !1 }) : { async: !1 }, a = t._zod.run({ value: r, issues: [] }, s);
  if (a instanceof Promise)
    throw new de();
  if (a.issues.length) {
    const i = new ((o == null ? void 0 : o.Err) ?? e)(a.issues.map((c) => re(c, s, te())));
    throw St(i, o == null ? void 0 : o.callee), i;
  }
  return a.value;
}, et = (e) => async (t, r, n, o) => {
  const s = n ? Object.assign(n, { async: !0 }) : { async: !0 };
  let a = t._zod.run({ value: r, issues: [] }, s);
  if (a instanceof Promise && (a = await a), a.issues.length) {
    const i = new ((o == null ? void 0 : o.Err) ?? e)(a.issues.map((c) => re(c, s, te())));
    throw St(i, o == null ? void 0 : o.callee), i;
  }
  return a.value;
}, Fe = (e) => (t, r, n) => {
  const o = n ? { ...n, async: !1 } : { async: !1 }, s = t._zod.run({ value: r, issues: [] }, o);
  if (s instanceof Promise)
    throw new de();
  return s.issues.length ? {
    success: !1,
    error: new (e ?? Pt)(s.issues.map((a) => re(a, o, te())))
  } : { success: !0, data: s.value };
}, vr = /* @__PURE__ */ Fe(Ct), De = (e) => async (t, r, n) => {
  const o = n ? Object.assign(n, { async: !0 }) : { async: !0 };
  let s = t._zod.run({ value: r, issues: [] }, o);
  return s instanceof Promise && (s = await s), s.issues.length ? {
    success: !1,
    error: new e(s.issues.map((a) => re(a, o, te())))
  } : { success: !0, data: s.value };
}, yr = /* @__PURE__ */ De(Ct), kr = (e) => (t, r, n) => {
  const o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return Qe(e)(t, r, o);
}, Ir = (e) => (t, r, n) => Qe(e)(t, r, n), xr = (e) => async (t, r, n) => {
  const o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return et(e)(t, r, o);
}, $r = (e) => async (t, r, n) => et(e)(t, r, n), Er = (e) => (t, r, n) => {
  const o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return Fe(e)(t, r, o);
}, zr = (e) => (t, r, n) => Fe(e)(t, r, n), Tr = (e) => async (t, r, n) => {
  const o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return De(e)(t, r, o);
}, Zr = (e) => async (t, r, n) => De(e)(t, r, n), Sr = /^[cC][^\s-]{8,}$/, Or = /^[0-9a-z]+$/, Mr = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, Pr = /^[0-9a-vA-V]{20}$/, Cr = /^[A-Za-z0-9]{27}$/, Nr = /^[a-zA-Z0-9_-]{21}$/, Fr = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Dr = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, ut = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, Lr = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Rr = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function Br() {
  return new RegExp(Rr, "u");
}
const jr = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Ur = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, qr = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Jr = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Wr = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Nt = /^[A-Za-z0-9_-]*$/, Vr = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Gr = /^\+(?:[0-9]){6,14}[0-9]$/, Ft = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", Hr = /* @__PURE__ */ new RegExp(`^${Ft}$`);
function Dt(e) {
  const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function Kr(e) {
  return new RegExp(`^${Dt(e)}$`);
}
function Yr(e) {
  const t = Dt({ precision: e.precision }), r = ["Z"];
  e.local && r.push(""), e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${t}(?:${r.join("|")})`;
  return new RegExp(`^${Ft}T(?:${n})$`);
}
const Xr = (e) => {
  const t = e ? `[\\s\\S]{${(e == null ? void 0 : e.minimum) ?? 0},${(e == null ? void 0 : e.maximum) ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, Qr = /^-?\d+$/, en = /^-?\d+(?:\.\d+)?/, tn = /^(?:true|false)$/i, rn = /^[^A-Z]*$/, nn = /^[^a-z]*$/, R = /* @__PURE__ */ u("$ZodCheck", (e, t) => {
  var r;
  e._zod ?? (e._zod = {}), e._zod.def = t, (r = e._zod).onattach ?? (r.onattach = []);
}), Lt = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Rt = /* @__PURE__ */ u("$ZodCheckLessThan", (e, t) => {
  R.init(e, t);
  const r = Lt[typeof t.value];
  e._zod.onattach.push((n) => {
    const o = n._zod.bag, s = (t.inclusive ? o.maximum : o.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < s && (t.inclusive ? o.maximum = t.value : o.exclusiveMaximum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value <= t.value : n.value < t.value) || n.issues.push({
      origin: r,
      code: "too_big",
      maximum: t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Bt = /* @__PURE__ */ u("$ZodCheckGreaterThan", (e, t) => {
  R.init(e, t);
  const r = Lt[typeof t.value];
  e._zod.onattach.push((n) => {
    const o = n._zod.bag, s = (t.inclusive ? o.minimum : o.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > s && (t.inclusive ? o.minimum = t.value : o.exclusiveMinimum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value >= t.value : n.value > t.value) || n.issues.push({
      origin: r,
      code: "too_small",
      minimum: t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), on = /* @__PURE__ */ u("$ZodCheckMultipleOf", (e, t) => {
  R.init(e, t), e._zod.onattach.push((r) => {
    var n;
    (n = r._zod.bag).multipleOf ?? (n.multipleOf = t.value);
  }), e._zod.check = (r) => {
    if (typeof r.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? r.value % t.value === BigInt(0) : ar(r.value, t.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), sn = /* @__PURE__ */ u("$ZodCheckNumberFormat", (e, t) => {
  var a;
  R.init(e, t), t.format = t.format || "float64";
  const r = (a = t.format) == null ? void 0 : a.includes("int"), n = r ? "int" : "number", [o, s] = gr[t.format];
  e._zod.onattach.push((i) => {
    const c = i._zod.bag;
    c.format = t.format, c.minimum = o, c.maximum = s, r && (c.pattern = Qr);
  }), e._zod.check = (i) => {
    const c = i.value;
    if (r) {
      if (!Number.isInteger(c)) {
        i.issues.push({
          expected: n,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? i.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          continue: !t.abort
        }) : i.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          continue: !t.abort
        });
        return;
      }
    }
    c < o && i.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), c > s && i.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: s,
      inst: e
    });
  };
}), an = /* @__PURE__ */ u("$ZodCheckMaxLength", (e, t) => {
  var r;
  R.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    const o = n.value;
    return !Ke(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    const o = n._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < o && (n._zod.bag.maximum = t.maximum);
  }), e._zod.check = (n) => {
    const o = n.value;
    if (o.length <= t.maximum)
      return;
    const a = Xe(o);
    n.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), cn = /* @__PURE__ */ u("$ZodCheckMinLength", (e, t) => {
  var r;
  R.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    const o = n.value;
    return !Ke(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    const o = n._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > o && (n._zod.bag.minimum = t.minimum);
  }), e._zod.check = (n) => {
    const o = n.value;
    if (o.length >= t.minimum)
      return;
    const a = Xe(o);
    n.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), un = /* @__PURE__ */ u("$ZodCheckLengthEquals", (e, t) => {
  var r;
  R.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    const o = n.value;
    return !Ke(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    const o = n._zod.bag;
    o.minimum = t.length, o.maximum = t.length, o.length = t.length;
  }), e._zod.check = (n) => {
    const o = n.value, s = o.length;
    if (s === t.length)
      return;
    const a = Xe(o), i = s > t.length;
    n.issues.push({
      origin: a,
      ...i ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Le = /* @__PURE__ */ u("$ZodCheckStringFormat", (e, t) => {
  var r, n;
  R.init(e, t), e._zod.onattach.push((o) => {
    const s = o._zod.bag;
    s.format = t.format, t.pattern && (s.patterns ?? (s.patterns = /* @__PURE__ */ new Set()), s.patterns.add(t.pattern));
  }), t.pattern ? (r = e._zod).check ?? (r.check = (o) => {
    t.pattern.lastIndex = 0, !t.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: o.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (n = e._zod).check ?? (n.check = () => {
  });
}), ln = /* @__PURE__ */ u("$ZodCheckRegex", (e, t) => {
  Le.init(e, t), e._zod.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), gn = /* @__PURE__ */ u("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = rn), Le.init(e, t);
}), dn = /* @__PURE__ */ u("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = nn), Le.init(e, t);
}), mn = /* @__PURE__ */ u("$ZodCheckIncludes", (e, t) => {
  R.init(e, t);
  const r = Ne(t.includes), n = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${r}` : r);
  t.pattern = n, e._zod.onattach.push((o) => {
    const s = o._zod.bag;
    s.patterns ?? (s.patterns = /* @__PURE__ */ new Set()), s.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.includes(t.includes, t.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), fn = /* @__PURE__ */ u("$ZodCheckStartsWith", (e, t) => {
  R.init(e, t);
  const r = new RegExp(`^${Ne(t.prefix)}.*`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    const o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.startsWith(t.prefix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), hn = /* @__PURE__ */ u("$ZodCheckEndsWith", (e, t) => {
  R.init(e, t);
  const r = new RegExp(`.*${Ne(t.suffix)}$`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    const o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.endsWith(t.suffix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), pn = /* @__PURE__ */ u("$ZodCheckOverwrite", (e, t) => {
  R.init(e, t), e._zod.check = (r) => {
    r.value = t.tx(r.value);
  };
});
class wn {
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    const n = t.split(`
`).filter((a) => a), o = Math.min(...n.map((a) => a.length - a.trimStart().length)), s = n.map((a) => a.slice(o)).map((a) => " ".repeat(this.indent * 2) + a);
    for (const a of s)
      this.content.push(a);
  }
  compile() {
    const t = Function, r = this == null ? void 0 : this.args, o = [...((this == null ? void 0 : this.content) ?? [""]).map((s) => `  ${s}`)];
    return new t(...r, o.join(`
`));
  }
}
const bn = {
  major: 4,
  minor: 1,
  patch: 8
}, S = /* @__PURE__ */ u("$ZodType", (e, t) => {
  var o;
  var r;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = bn;
  const n = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && n.unshift(e);
  for (const s of n)
    for (const a of s._zod.onattach)
      a(e);
  if (n.length === 0)
    (r = e._zod).deferred ?? (r.deferred = []), (o = e._zod.deferred) == null || o.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const s = (i, c, l) => {
      let g = le(i), m;
      for (const b of c) {
        if (b._zod.def.when) {
          if (!b._zod.def.when(i))
            continue;
        } else if (g)
          continue;
        const h = i.issues.length, y = b._zod.check(i);
        if (y instanceof Promise && (l == null ? void 0 : l.async) === !1)
          throw new de();
        if (m || y instanceof Promise)
          m = (m ?? Promise.resolve()).then(async () => {
            await y, i.issues.length !== h && (g || (g = le(i, h)));
          });
        else {
          if (i.issues.length === h)
            continue;
          g || (g = le(i, h));
        }
      }
      return m ? m.then(() => i) : i;
    }, a = (i, c, l) => {
      if (le(i))
        return i.aborted = !0, i;
      const g = s(c, n, l);
      if (g instanceof Promise) {
        if (l.async === !1)
          throw new de();
        return g.then((m) => e._zod.parse(m, l));
      }
      return e._zod.parse(g, l);
    };
    e._zod.run = (i, c) => {
      if (c.skipChecks)
        return e._zod.parse(i, c);
      if (c.direction === "backward") {
        const g = e._zod.parse({ value: i.value, issues: [] }, { ...c, skipChecks: !0 });
        return g instanceof Promise ? g.then((m) => a(m, i, c)) : a(g, i, c);
      }
      const l = e._zod.parse(i, c);
      if (l instanceof Promise) {
        if (c.async === !1)
          throw new de();
        return l.then((g) => s(g, n, c));
      }
      return s(l, n, c);
    };
  }
  e["~standard"] = {
    validate: (s) => {
      var a;
      try {
        const i = vr(e, s);
        return i.success ? { value: i.data } : { issues: (a = i.error) == null ? void 0 : a.issues };
      } catch {
        return yr(e, s).then((c) => {
          var l;
          return c.success ? { value: c.data } : { issues: (l = c.error) == null ? void 0 : l.issues };
        });
      }
    },
    vendor: "zod",
    version: 1
  };
}), tt = /* @__PURE__ */ u("$ZodString", (e, t) => {
  var r;
  S.init(e, t), e._zod.pattern = [...((r = e == null ? void 0 : e._zod.bag) == null ? void 0 : r.patterns) ?? []].pop() ?? Xr(e._zod.bag), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), z = /* @__PURE__ */ u("$ZodStringFormat", (e, t) => {
  Le.init(e, t), tt.init(e, t);
}), _n = /* @__PURE__ */ u("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = Dr), z.init(e, t);
}), An = /* @__PURE__ */ u("$ZodUUID", (e, t) => {
  if (t.version) {
    const n = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (n === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = ut(n));
  } else
    t.pattern ?? (t.pattern = ut());
  z.init(e, t);
}), vn = /* @__PURE__ */ u("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Lr), z.init(e, t);
}), yn = /* @__PURE__ */ u("$ZodURL", (e, t) => {
  z.init(e, t), e._zod.check = (r) => {
    try {
      const n = r.value.trim(), o = new URL(n);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(o.hostname) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: Vr.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(o.protocol.endsWith(":") ? o.protocol.slice(0, -1) : o.protocol) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? r.value = o.href : r.value = n;
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), kn = /* @__PURE__ */ u("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Br()), z.init(e, t);
}), In = /* @__PURE__ */ u("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = Nr), z.init(e, t);
}), xn = /* @__PURE__ */ u("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Sr), z.init(e, t);
}), $n = /* @__PURE__ */ u("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Or), z.init(e, t);
}), En = /* @__PURE__ */ u("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Mr), z.init(e, t);
}), zn = /* @__PURE__ */ u("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = Pr), z.init(e, t);
}), Tn = /* @__PURE__ */ u("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Cr), z.init(e, t);
}), Zn = /* @__PURE__ */ u("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Yr(t)), z.init(e, t);
}), Sn = /* @__PURE__ */ u("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Hr), z.init(e, t);
}), On = /* @__PURE__ */ u("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Kr(t)), z.init(e, t);
}), Mn = /* @__PURE__ */ u("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Fr), z.init(e, t);
}), Pn = /* @__PURE__ */ u("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = jr), z.init(e, t), e._zod.onattach.push((r) => {
    const n = r._zod.bag;
    n.format = "ipv4";
  });
}), Cn = /* @__PURE__ */ u("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Ur), z.init(e, t), e._zod.onattach.push((r) => {
    const n = r._zod.bag;
    n.format = "ipv6";
  }), e._zod.check = (r) => {
    try {
      new URL(`http://[${r.value}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Nn = /* @__PURE__ */ u("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = qr), z.init(e, t);
}), Fn = /* @__PURE__ */ u("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Jr), z.init(e, t), e._zod.check = (r) => {
    const n = r.value.split("/");
    try {
      if (n.length !== 2)
        throw new Error();
      const [o, s] = n;
      if (!s)
        throw new Error();
      const a = Number(s);
      if (`${a}` !== s)
        throw new Error();
      if (a < 0 || a > 128)
        throw new Error();
      new URL(`http://[${o}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function jt(e) {
  if (e === "")
    return !0;
  if (e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
const Dn = /* @__PURE__ */ u("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Wr), z.init(e, t), e._zod.onattach.push((r) => {
    r._zod.bag.contentEncoding = "base64";
  }), e._zod.check = (r) => {
    jt(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Ln(e) {
  if (!Nt.test(e))
    return !1;
  const t = e.replace(/[-_]/g, (n) => n === "-" ? "+" : "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return jt(r);
}
const Rn = /* @__PURE__ */ u("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = Nt), z.init(e, t), e._zod.onattach.push((r) => {
    r._zod.bag.contentEncoding = "base64url";
  }), e._zod.check = (r) => {
    Ln(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Bn = /* @__PURE__ */ u("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Gr), z.init(e, t);
});
function jn(e, t = null) {
  try {
    const r = e.split(".");
    if (r.length !== 3)
      return !1;
    const [n] = r;
    if (!n)
      return !1;
    const o = JSON.parse(atob(n));
    return !("typ" in o && (o == null ? void 0 : o.typ) !== "JWT" || !o.alg || t && (!("alg" in o) || o.alg !== t));
  } catch {
    return !1;
  }
}
const Un = /* @__PURE__ */ u("$ZodJWT", (e, t) => {
  z.init(e, t), e._zod.check = (r) => {
    jn(r.value, t.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ut = /* @__PURE__ */ u("$ZodNumber", (e, t) => {
  S.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? en, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = Number(r.value);
      } catch {
      }
    const o = r.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return r;
    const s = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : "Infinity" : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: e,
      ...s ? { received: s } : {}
    }), r;
  };
}), qn = /* @__PURE__ */ u("$ZodNumber", (e, t) => {
  sn.init(e, t), Ut.init(e, t);
}), Jn = /* @__PURE__ */ u("$ZodBoolean", (e, t) => {
  S.init(e, t), e._zod.pattern = tn, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = !!r.value;
      } catch {
      }
    const o = r.value;
    return typeof o == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Wn = /* @__PURE__ */ u("$ZodUnknown", (e, t) => {
  S.init(e, t), e._zod.parse = (r) => r;
}), Vn = /* @__PURE__ */ u("$ZodNever", (e, t) => {
  S.init(e, t), e._zod.parse = (r, n) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: e
  }), r);
});
function lt(e, t, r) {
  e.issues.length && t.issues.push(...ge(r, e.issues)), t.value[r] = e.value;
}
const Gn = /* @__PURE__ */ u("$ZodArray", (e, t) => {
  S.init(e, t), e._zod.parse = (r, n) => {
    const o = r.value;
    if (!Array.isArray(o))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    r.value = Array(o.length);
    const s = [];
    for (let a = 0; a < o.length; a++) {
      const i = o[a], c = t.element._zod.run({
        value: i,
        issues: []
      }, n);
      c instanceof Promise ? s.push(c.then((l) => lt(l, r, a))) : lt(c, r, a);
    }
    return s.length ? Promise.all(s).then(() => r) : r;
  };
});
function Se(e, t, r, n) {
  e.issues.length && t.issues.push(...ge(r, e.issues)), e.value === void 0 ? r in n && (t.value[r] = void 0) : t.value[r] = e.value;
}
function qt(e) {
  var n, o, s, a;
  const t = Object.keys(e.shape);
  for (const i of t)
    if (!((a = (s = (o = (n = e.shape) == null ? void 0 : n[i]) == null ? void 0 : o._zod) == null ? void 0 : s.traits) != null && a.has("$ZodType")))
      throw new Error(`Invalid element at key "${i}": expected a Zod schema`);
  const r = lr(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(r)
  };
}
function Jt(e, t, r, n, o, s) {
  const a = [], i = o.keySet, c = o.catchall._zod, l = c.def.type;
  for (const g of Object.keys(t)) {
    if (i.has(g))
      continue;
    if (l === "never") {
      a.push(g);
      continue;
    }
    const m = c.run({ value: t[g], issues: [] }, n);
    m instanceof Promise ? e.push(m.then((b) => Se(b, r, g, t))) : Se(m, r, g, t);
  }
  return a.length && r.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: s
  }), e.length ? Promise.all(e).then(() => r) : r;
}
const Hn = /* @__PURE__ */ u("$ZodObject", (e, t) => {
  S.init(e, t);
  const r = He(() => qt(t));
  $(e._zod, "propValues", () => {
    const a = t.shape, i = {};
    for (const c in a) {
      const l = a[c]._zod;
      if (l.values) {
        i[c] ?? (i[c] = /* @__PURE__ */ new Set());
        for (const g of l.values)
          i[c].add(g);
      }
    }
    return i;
  });
  const n = Ze, o = t.catchall;
  let s;
  e._zod.parse = (a, i) => {
    s ?? (s = r.value);
    const c = a.value;
    if (!n(c))
      return a.issues.push({
        expected: "object",
        code: "invalid_type",
        input: c,
        inst: e
      }), a;
    a.value = {};
    const l = [], g = s.shape;
    for (const m of s.keys) {
      const h = g[m]._zod.run({ value: c[m], issues: [] }, i);
      h instanceof Promise ? l.push(h.then((y) => Se(y, a, m, c))) : Se(h, a, m, c);
    }
    return o ? Jt(l, c, a, i, r.value, e) : l.length ? Promise.all(l).then(() => a) : a;
  };
}), Kn = /* @__PURE__ */ u("$ZodObjectJIT", (e, t) => {
  Hn.init(e, t);
  const r = e._zod.parse, n = He(() => qt(t)), o = (b) => {
    const h = new wn(["shape", "payload", "ctx"]), y = n.value, O = (U) => {
      const q = ct(U);
      return `shape[${q}]._zod.run({ value: input[${q}], issues: [] }, ctx)`;
    };
    h.write("const input = payload.value;");
    const F = /* @__PURE__ */ Object.create(null);
    let A = 0;
    for (const U of y.keys)
      F[U] = `key_${A++}`;
    h.write("const newResult = {};");
    for (const U of y.keys) {
      const q = F[U], Q = ct(U);
      h.write(`const ${q} = ${O(U)};`), h.write(`
        if (${q}.issues.length) {
          payload.issues = payload.issues.concat(${q}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${Q}, ...iss.path] : [${Q}]
          })));
        }
        
        
        if (${q}.value === undefined) {
          if (${Q} in input) {
            newResult[${Q}] = undefined;
          }
        } else {
          newResult[${Q}] = ${q}.value;
        }
        
      `);
    }
    h.write("payload.value = newResult;"), h.write("return payload;");
    const j = h.compile();
    return (U, q) => j(b, U, q);
  };
  let s;
  const a = Ze, i = !Zt.jitless, l = i && cr.value, g = t.catchall;
  let m;
  e._zod.parse = (b, h) => {
    m ?? (m = n.value);
    const y = b.value;
    return a(y) ? i && l && (h == null ? void 0 : h.async) === !1 && h.jitless !== !0 ? (s || (s = o(t.shape)), b = s(b, h), g ? Jt([], y, b, h, m, e) : b) : r(b, h) : (b.issues.push({
      expected: "object",
      code: "invalid_type",
      input: y,
      inst: e
    }), b);
  };
});
function gt(e, t, r, n) {
  for (const s of e)
    if (s.issues.length === 0)
      return t.value = s.value, t;
  const o = e.filter((s) => !le(s));
  return o.length === 1 ? (t.value = o[0].value, o[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((s) => s.issues.map((a) => re(a, n, te())))
  }), t);
}
const Yn = /* @__PURE__ */ u("$ZodUnion", (e, t) => {
  S.init(e, t), $(e._zod, "optin", () => t.options.some((o) => o._zod.optin === "optional") ? "optional" : void 0), $(e._zod, "optout", () => t.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0), $(e._zod, "values", () => {
    if (t.options.every((o) => o._zod.values))
      return new Set(t.options.flatMap((o) => Array.from(o._zod.values)));
  }), $(e._zod, "pattern", () => {
    if (t.options.every((o) => o._zod.pattern)) {
      const o = t.options.map((s) => s._zod.pattern);
      return new RegExp(`^(${o.map((s) => Ye(s.source)).join("|")})$`);
    }
  });
  const r = t.options.length === 1, n = t.options[0]._zod.run;
  e._zod.parse = (o, s) => {
    if (r)
      return n(o, s);
    let a = !1;
    const i = [];
    for (const c of t.options) {
      const l = c._zod.run({
        value: o.value,
        issues: []
      }, s);
      if (l instanceof Promise)
        i.push(l), a = !0;
      else {
        if (l.issues.length === 0)
          return l;
        i.push(l);
      }
    }
    return a ? Promise.all(i).then((c) => gt(c, o, e, s)) : gt(i, o, e, s);
  };
}), Xn = /* @__PURE__ */ u("$ZodIntersection", (e, t) => {
  S.init(e, t), e._zod.parse = (r, n) => {
    const o = r.value, s = t.left._zod.run({ value: o, issues: [] }, n), a = t.right._zod.run({ value: o, issues: [] }, n);
    return s instanceof Promise || a instanceof Promise ? Promise.all([s, a]).then(([c, l]) => dt(r, c, l)) : dt(r, s, a);
  };
});
function Je(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (fe(e) && fe(t)) {
    const r = Object.keys(t), n = Object.keys(e).filter((s) => r.indexOf(s) !== -1), o = { ...e, ...t };
    for (const s of n) {
      const a = Je(e[s], t[s]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [s, ...a.mergeErrorPath]
        };
      o[s] = a.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    const r = [];
    for (let n = 0; n < e.length; n++) {
      const o = e[n], s = t[n], a = Je(o, s);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...a.mergeErrorPath]
        };
      r.push(a.data);
    }
    return { valid: !0, data: r };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function dt(e, t, r) {
  if (t.issues.length && e.issues.push(...t.issues), r.issues.length && e.issues.push(...r.issues), le(e))
    return e;
  const n = Je(t.value, r.value);
  if (!n.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(n.mergeErrorPath)}`);
  return e.value = n.data, e;
}
const Qn = /* @__PURE__ */ u("$ZodRecord", (e, t) => {
  S.init(e, t), e._zod.parse = (r, n) => {
    const o = r.value;
    if (!fe(o))
      return r.issues.push({
        expected: "record",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    const s = [];
    if (t.keyType._zod.values) {
      const a = t.keyType._zod.values;
      r.value = {};
      for (const c of a)
        if (typeof c == "string" || typeof c == "number" || typeof c == "symbol") {
          const l = t.valueType._zod.run({ value: o[c], issues: [] }, n);
          l instanceof Promise ? s.push(l.then((g) => {
            g.issues.length && r.issues.push(...ge(c, g.issues)), r.value[c] = g.value;
          })) : (l.issues.length && r.issues.push(...ge(c, l.issues)), r.value[c] = l.value);
        }
      let i;
      for (const c in o)
        a.has(c) || (i = i ?? [], i.push(c));
      i && i.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: i
      });
    } else {
      r.value = {};
      for (const a of Reflect.ownKeys(o)) {
        if (a === "__proto__")
          continue;
        const i = t.keyType._zod.run({ value: a, issues: [] }, n);
        if (i instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (i.issues.length) {
          r.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: i.issues.map((l) => re(l, n, te())),
            input: a,
            path: [a],
            inst: e
          }), r.value[i.value] = i.value;
          continue;
        }
        const c = t.valueType._zod.run({ value: o[a], issues: [] }, n);
        c instanceof Promise ? s.push(c.then((l) => {
          l.issues.length && r.issues.push(...ge(a, l.issues)), r.value[i.value] = l.value;
        })) : (c.issues.length && r.issues.push(...ge(a, c.issues)), r.value[i.value] = c.value);
      }
    }
    return s.length ? Promise.all(s).then(() => r) : r;
  };
}), eo = /* @__PURE__ */ u("$ZodEnum", (e, t) => {
  S.init(e, t);
  const r = sr(t.entries), n = new Set(r);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${r.filter((o) => ur.has(typeof o)).map((o) => typeof o == "string" ? Ne(o) : o.toString()).join("|")})$`), e._zod.parse = (o, s) => {
    const a = o.value;
    return n.has(a) || o.issues.push({
      code: "invalid_value",
      values: r,
      input: a,
      inst: e
    }), o;
  };
}), to = /* @__PURE__ */ u("$ZodTransform", (e, t) => {
  S.init(e, t), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Tt(e.constructor.name);
    const o = t.transform(r.value, r);
    if (n.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((a) => (r.value = a, r));
    if (o instanceof Promise)
      throw new de();
    return r.value = o, r;
  };
});
function mt(e, t) {
  return e.issues.length && t === void 0 ? { issues: [], value: void 0 } : e;
}
const ro = /* @__PURE__ */ u("$ZodOptional", (e, t) => {
  S.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", $(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), $(e._zod, "pattern", () => {
    const r = t.innerType._zod.pattern;
    return r ? new RegExp(`^(${Ye(r.source)})?$`) : void 0;
  }), e._zod.parse = (r, n) => {
    if (t.innerType._zod.optin === "optional") {
      const o = t.innerType._zod.run(r, n);
      return o instanceof Promise ? o.then((s) => mt(s, r.value)) : mt(o, r.value);
    }
    return r.value === void 0 ? r : t.innerType._zod.run(r, n);
  };
}), no = /* @__PURE__ */ u("$ZodNullable", (e, t) => {
  S.init(e, t), $(e._zod, "optin", () => t.innerType._zod.optin), $(e._zod, "optout", () => t.innerType._zod.optout), $(e._zod, "pattern", () => {
    const r = t.innerType._zod.pattern;
    return r ? new RegExp(`^(${Ye(r.source)}|null)$`) : void 0;
  }), $(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (r, n) => r.value === null ? r : t.innerType._zod.run(r, n);
}), oo = /* @__PURE__ */ u("$ZodDefault", (e, t) => {
  S.init(e, t), e._zod.optin = "optional", $(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    if (r.value === void 0)
      return r.value = t.defaultValue, r;
    const o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => ft(s, t)) : ft(o, t);
  };
});
function ft(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
const so = /* @__PURE__ */ u("$ZodPrefault", (e, t) => {
  S.init(e, t), e._zod.optin = "optional", $(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => (n.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, n));
}), ao = /* @__PURE__ */ u("$ZodNonOptional", (e, t) => {
  S.init(e, t), $(e._zod, "values", () => {
    const r = t.innerType._zod.values;
    return r ? new Set([...r].filter((n) => n !== void 0)) : void 0;
  }), e._zod.parse = (r, n) => {
    const o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => ht(s, e)) : ht(o, e);
  };
});
function ht(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
const io = /* @__PURE__ */ u("$ZodCatch", (e, t) => {
  S.init(e, t), $(e._zod, "optin", () => t.innerType._zod.optin), $(e._zod, "optout", () => t.innerType._zod.optout), $(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    const o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => (r.value = s.value, s.issues.length && (r.value = t.catchValue({
      ...r,
      error: {
        issues: s.issues.map((a) => re(a, n, te()))
      },
      input: r.value
    }), r.issues = []), r)) : (r.value = o.value, o.issues.length && (r.value = t.catchValue({
      ...r,
      error: {
        issues: o.issues.map((s) => re(s, n, te()))
      },
      input: r.value
    }), r.issues = []), r);
  };
}), co = /* @__PURE__ */ u("$ZodPipe", (e, t) => {
  S.init(e, t), $(e._zod, "values", () => t.in._zod.values), $(e._zod, "optin", () => t.in._zod.optin), $(e._zod, "optout", () => t.out._zod.optout), $(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, n) => {
    if (n.direction === "backward") {
      const s = t.out._zod.run(r, n);
      return s instanceof Promise ? s.then((a) => ke(a, t.in, n)) : ke(s, t.in, n);
    }
    const o = t.in._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => ke(s, t.out, n)) : ke(o, t.out, n);
  };
});
function ke(e, t, r) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, r);
}
const uo = /* @__PURE__ */ u("$ZodReadonly", (e, t) => {
  S.init(e, t), $(e._zod, "propValues", () => t.innerType._zod.propValues), $(e._zod, "values", () => t.innerType._zod.values), $(e._zod, "optin", () => t.innerType._zod.optin), $(e._zod, "optout", () => t.innerType._zod.optout), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    const o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then(pt) : pt(o);
  };
});
function pt(e) {
  return e.value = Object.freeze(e.value), e;
}
const lo = /* @__PURE__ */ u("$ZodCustom", (e, t) => {
  R.init(e, t), S.init(e, t), e._zod.parse = (r, n) => r, e._zod.check = (r) => {
    const n = r.value, o = t.fn(n);
    if (o instanceof Promise)
      return o.then((s) => wt(s, r, n, e));
    wt(o, r, n, e);
  };
});
function wt(e, t, r, n) {
  if (!e) {
    const o = {
      code: "custom",
      input: r,
      inst: n,
      // incorporates params.error into issue reporting
      path: [...n._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !n._zod.def.abort
      // params: inst._zod.def.params,
    };
    n._zod.def.params && (o.params = n._zod.def.params), t.issues.push(Ae(o));
  }
}
class go {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...r) {
    const n = r[0];
    if (this._map.set(t, n), n && typeof n == "object" && "id" in n) {
      if (this._idmap.has(n.id))
        throw new Error(`ID ${n.id} already exists in the registry`);
      this._idmap.set(n.id, t);
    }
    return this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    const r = this._map.get(t);
    return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(t), this;
  }
  get(t) {
    const r = t._zod.parent;
    if (r) {
      const n = { ...this.get(r) ?? {} };
      delete n.id;
      const o = { ...n, ...this._map.get(t) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
}
function mo() {
  return new go();
}
const Ie = /* @__PURE__ */ mo();
function fo(e, t) {
  return new e({
    type: "string",
    ...d(t)
  });
}
function ho(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function bt(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function po(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function wo(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...d(t)
  });
}
function bo(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...d(t)
  });
}
function _o(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...d(t)
  });
}
function Ao(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function vo(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function yo(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function ko(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Io(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function xo(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function $o(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Eo(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function zo(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function To(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Zo(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function So(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Oo(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Mo(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Po(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function Co(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...d(t)
  });
}
function No(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...d(t)
  });
}
function Fo(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...d(t)
  });
}
function Do(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...d(t)
  });
}
function Lo(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...d(t)
  });
}
function Ro(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...d(t)
  });
}
function Bo(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...d(t)
  });
}
function jo(e, t) {
  return new e({
    type: "boolean",
    ...d(t)
  });
}
function Uo(e) {
  return new e({
    type: "unknown"
  });
}
function qo(e, t) {
  return new e({
    type: "never",
    ...d(t)
  });
}
function _t(e, t) {
  return new Rt({
    check: "less_than",
    ...d(t),
    value: e,
    inclusive: !1
  });
}
function Be(e, t) {
  return new Rt({
    check: "less_than",
    ...d(t),
    value: e,
    inclusive: !0
  });
}
function At(e, t) {
  return new Bt({
    check: "greater_than",
    ...d(t),
    value: e,
    inclusive: !1
  });
}
function je(e, t) {
  return new Bt({
    check: "greater_than",
    ...d(t),
    value: e,
    inclusive: !0
  });
}
function vt(e, t) {
  return new on({
    check: "multiple_of",
    ...d(t),
    value: e
  });
}
function Wt(e, t) {
  return new an({
    check: "max_length",
    ...d(t),
    maximum: e
  });
}
function Oe(e, t) {
  return new cn({
    check: "min_length",
    ...d(t),
    minimum: e
  });
}
function Vt(e, t) {
  return new un({
    check: "length_equals",
    ...d(t),
    length: e
  });
}
function Jo(e, t) {
  return new ln({
    check: "string_format",
    format: "regex",
    ...d(t),
    pattern: e
  });
}
function Wo(e) {
  return new gn({
    check: "string_format",
    format: "lowercase",
    ...d(e)
  });
}
function Vo(e) {
  return new dn({
    check: "string_format",
    format: "uppercase",
    ...d(e)
  });
}
function Go(e, t) {
  return new mn({
    check: "string_format",
    format: "includes",
    ...d(t),
    includes: e
  });
}
function Ho(e, t) {
  return new fn({
    check: "string_format",
    format: "starts_with",
    ...d(t),
    prefix: e
  });
}
function Ko(e, t) {
  return new hn({
    check: "string_format",
    format: "ends_with",
    ...d(t),
    suffix: e
  });
}
function ve(e) {
  return new pn({
    check: "overwrite",
    tx: e
  });
}
function Yo(e) {
  return ve((t) => t.normalize(e));
}
function Xo() {
  return ve((e) => e.trim());
}
function Qo() {
  return ve((e) => e.toLowerCase());
}
function es() {
  return ve((e) => e.toUpperCase());
}
function ts(e, t, r) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...d(r)
  });
}
function rs(e, t, r) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...d(r)
  });
}
function ns(e) {
  const t = os((r) => (r.addIssue = (n) => {
    if (typeof n == "string")
      r.issues.push(Ae(n, r.value, t._zod.def));
    else {
      const o = n;
      o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), o.input ?? (o.input = r.value), o.inst ?? (o.inst = t), o.continue ?? (o.continue = !t._zod.def.abort), r.issues.push(Ae(o));
    }
  }, e(r.value, r)));
  return t;
}
function os(e, t) {
  const r = new R({
    check: "custom",
    ...d(t)
  });
  return r._zod.check = e, r;
}
const ss = /* @__PURE__ */ u("ZodISODateTime", (e, t) => {
  Zn.init(e, t), T.init(e, t);
});
function as(e) {
  return No(ss, e);
}
const is = /* @__PURE__ */ u("ZodISODate", (e, t) => {
  Sn.init(e, t), T.init(e, t);
});
function cs(e) {
  return Fo(is, e);
}
const us = /* @__PURE__ */ u("ZodISOTime", (e, t) => {
  On.init(e, t), T.init(e, t);
});
function ls(e) {
  return Do(us, e);
}
const gs = /* @__PURE__ */ u("ZodISODuration", (e, t) => {
  Mn.init(e, t), T.init(e, t);
});
function ds(e) {
  return Lo(gs, e);
}
const ms = (e, t) => {
  Pt.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
    format: {
      value: (r) => Ar(e, r)
      // enumerable: false,
    },
    flatten: {
      value: (r) => _r(e, r)
      // enumerable: false,
    },
    addIssue: {
      value: (r) => {
        e.issues.push(r), e.message = JSON.stringify(e.issues, qe, 2);
      }
      // enumerable: false,
    },
    addIssues: {
      value: (r) => {
        e.issues.push(...r), e.message = JSON.stringify(e.issues, qe, 2);
      }
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return e.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, H = u("ZodError", ms, {
  Parent: Error
}), fs = /* @__PURE__ */ Qe(H), hs = /* @__PURE__ */ et(H), ps = /* @__PURE__ */ Fe(H), ws = /* @__PURE__ */ De(H), bs = /* @__PURE__ */ kr(H), _s = /* @__PURE__ */ Ir(H), As = /* @__PURE__ */ xr(H), vs = /* @__PURE__ */ $r(H), ys = /* @__PURE__ */ Er(H), ks = /* @__PURE__ */ zr(H), Is = /* @__PURE__ */ Tr(H), xs = /* @__PURE__ */ Zr(H), M = /* @__PURE__ */ u("ZodType", (e, t) => (S.init(e, t), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.check = (...r) => e.clone(
  {
    ...t,
    checks: [
      ...t.checks ?? [],
      ...r.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
    ]
  }
  // { parent: true }
), e.clone = (r, n) => oe(e, r, n), e.brand = () => e, e.register = (r, n) => (r.add(e, n), e), e.parse = (r, n) => fs(e, r, n, { callee: e.parse }), e.safeParse = (r, n) => ps(e, r, n), e.parseAsync = async (r, n) => hs(e, r, n, { callee: e.parseAsync }), e.safeParseAsync = async (r, n) => ws(e, r, n), e.spa = e.safeParseAsync, e.encode = (r, n) => bs(e, r, n), e.decode = (r, n) => _s(e, r, n), e.encodeAsync = async (r, n) => As(e, r, n), e.decodeAsync = async (r, n) => vs(e, r, n), e.safeEncode = (r, n) => ys(e, r, n), e.safeDecode = (r, n) => ks(e, r, n), e.safeEncodeAsync = async (r, n) => Is(e, r, n), e.safeDecodeAsync = async (r, n) => xs(e, r, n), e.refine = (r, n) => e.check(pa(r, n)), e.superRefine = (r) => e.check(wa(r)), e.overwrite = (r) => e.check(ve(r)), e.optional = () => It(e), e.nullable = () => xt(e), e.nullish = () => It(xt(e)), e.nonoptional = (r) => ua(e, r), e.array = () => he(e), e.or = (r) => Xs([e, r]), e.and = (r) => ea(e, r), e.transform = (r) => $t(e, na(r)), e.default = (r) => aa(e, r), e.prefault = (r) => ca(e, r), e.catch = (r) => ga(e, r), e.pipe = (r) => $t(e, r), e.readonly = () => fa(e), e.describe = (r) => {
  const n = e.clone();
  return Ie.add(n, { description: r }), n;
}, Object.defineProperty(e, "description", {
  get() {
    var r;
    return (r = Ie.get(e)) == null ? void 0 : r.description;
  },
  configurable: !0
}), e.meta = (...r) => {
  if (r.length === 0)
    return Ie.get(e);
  const n = e.clone();
  return Ie.add(n, r[0]), n;
}, e.isOptional = () => e.safeParse(void 0).success, e.isNullable = () => e.safeParse(null).success, e)), Gt = /* @__PURE__ */ u("_ZodString", (e, t) => {
  tt.init(e, t), M.init(e, t);
  const r = e._zod.bag;
  e.format = r.format ?? null, e.minLength = r.minimum ?? null, e.maxLength = r.maximum ?? null, e.regex = (...n) => e.check(Jo(...n)), e.includes = (...n) => e.check(Go(...n)), e.startsWith = (...n) => e.check(Ho(...n)), e.endsWith = (...n) => e.check(Ko(...n)), e.min = (...n) => e.check(Oe(...n)), e.max = (...n) => e.check(Wt(...n)), e.length = (...n) => e.check(Vt(...n)), e.nonempty = (...n) => e.check(Oe(1, ...n)), e.lowercase = (n) => e.check(Wo(n)), e.uppercase = (n) => e.check(Vo(n)), e.trim = () => e.check(Xo()), e.normalize = (...n) => e.check(Yo(...n)), e.toLowerCase = () => e.check(Qo()), e.toUpperCase = () => e.check(es());
}), $s = /* @__PURE__ */ u("ZodString", (e, t) => {
  tt.init(e, t), Gt.init(e, t), e.email = (r) => e.check(ho(Es, r)), e.url = (r) => e.check(Ao(zs, r)), e.jwt = (r) => e.check(Co(Us, r)), e.emoji = (r) => e.check(vo(Ts, r)), e.guid = (r) => e.check(bt(yt, r)), e.uuid = (r) => e.check(po(xe, r)), e.uuidv4 = (r) => e.check(wo(xe, r)), e.uuidv6 = (r) => e.check(bo(xe, r)), e.uuidv7 = (r) => e.check(_o(xe, r)), e.nanoid = (r) => e.check(yo(Zs, r)), e.guid = (r) => e.check(bt(yt, r)), e.cuid = (r) => e.check(ko(Ss, r)), e.cuid2 = (r) => e.check(Io(Os, r)), e.ulid = (r) => e.check(xo(Ms, r)), e.base64 = (r) => e.check(Oo(Rs, r)), e.base64url = (r) => e.check(Mo(Bs, r)), e.xid = (r) => e.check($o(Ps, r)), e.ksuid = (r) => e.check(Eo(Cs, r)), e.ipv4 = (r) => e.check(zo(Ns, r)), e.ipv6 = (r) => e.check(To(Fs, r)), e.cidrv4 = (r) => e.check(Zo(Ds, r)), e.cidrv6 = (r) => e.check(So(Ls, r)), e.e164 = (r) => e.check(Po(js, r)), e.datetime = (r) => e.check(as(r)), e.date = (r) => e.check(cs(r)), e.time = (r) => e.check(ls(r)), e.duration = (r) => e.check(ds(r));
});
function D(e) {
  return fo($s, e);
}
const T = /* @__PURE__ */ u("ZodStringFormat", (e, t) => {
  z.init(e, t), Gt.init(e, t);
}), Es = /* @__PURE__ */ u("ZodEmail", (e, t) => {
  vn.init(e, t), T.init(e, t);
}), yt = /* @__PURE__ */ u("ZodGUID", (e, t) => {
  _n.init(e, t), T.init(e, t);
}), xe = /* @__PURE__ */ u("ZodUUID", (e, t) => {
  An.init(e, t), T.init(e, t);
}), zs = /* @__PURE__ */ u("ZodURL", (e, t) => {
  yn.init(e, t), T.init(e, t);
}), Ts = /* @__PURE__ */ u("ZodEmoji", (e, t) => {
  kn.init(e, t), T.init(e, t);
}), Zs = /* @__PURE__ */ u("ZodNanoID", (e, t) => {
  In.init(e, t), T.init(e, t);
}), Ss = /* @__PURE__ */ u("ZodCUID", (e, t) => {
  xn.init(e, t), T.init(e, t);
}), Os = /* @__PURE__ */ u("ZodCUID2", (e, t) => {
  $n.init(e, t), T.init(e, t);
}), Ms = /* @__PURE__ */ u("ZodULID", (e, t) => {
  En.init(e, t), T.init(e, t);
}), Ps = /* @__PURE__ */ u("ZodXID", (e, t) => {
  zn.init(e, t), T.init(e, t);
}), Cs = /* @__PURE__ */ u("ZodKSUID", (e, t) => {
  Tn.init(e, t), T.init(e, t);
}), Ns = /* @__PURE__ */ u("ZodIPv4", (e, t) => {
  Pn.init(e, t), T.init(e, t);
}), Fs = /* @__PURE__ */ u("ZodIPv6", (e, t) => {
  Cn.init(e, t), T.init(e, t);
}), Ds = /* @__PURE__ */ u("ZodCIDRv4", (e, t) => {
  Nn.init(e, t), T.init(e, t);
}), Ls = /* @__PURE__ */ u("ZodCIDRv6", (e, t) => {
  Fn.init(e, t), T.init(e, t);
}), Rs = /* @__PURE__ */ u("ZodBase64", (e, t) => {
  Dn.init(e, t), T.init(e, t);
}), Bs = /* @__PURE__ */ u("ZodBase64URL", (e, t) => {
  Rn.init(e, t), T.init(e, t);
}), js = /* @__PURE__ */ u("ZodE164", (e, t) => {
  Bn.init(e, t), T.init(e, t);
}), Us = /* @__PURE__ */ u("ZodJWT", (e, t) => {
  Un.init(e, t), T.init(e, t);
}), Ht = /* @__PURE__ */ u("ZodNumber", (e, t) => {
  Ut.init(e, t), M.init(e, t), e.gt = (n, o) => e.check(At(n, o)), e.gte = (n, o) => e.check(je(n, o)), e.min = (n, o) => e.check(je(n, o)), e.lt = (n, o) => e.check(_t(n, o)), e.lte = (n, o) => e.check(Be(n, o)), e.max = (n, o) => e.check(Be(n, o)), e.int = (n) => e.check(kt(n)), e.safe = (n) => e.check(kt(n)), e.positive = (n) => e.check(At(0, n)), e.nonnegative = (n) => e.check(je(0, n)), e.negative = (n) => e.check(_t(0, n)), e.nonpositive = (n) => e.check(Be(0, n)), e.multipleOf = (n, o) => e.check(vt(n, o)), e.step = (n, o) => e.check(vt(n, o)), e.finite = () => e;
  const r = e._zod.bag;
  e.minValue = Math.max(r.minimum ?? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(r.maximum ?? Number.POSITIVE_INFINITY, r.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (r.format ?? "").includes("int") || Number.isSafeInteger(r.multipleOf ?? 0.5), e.isFinite = !0, e.format = r.format ?? null;
});
function x(e) {
  return Ro(Ht, e);
}
const qs = /* @__PURE__ */ u("ZodNumberFormat", (e, t) => {
  qn.init(e, t), Ht.init(e, t);
});
function kt(e) {
  return Bo(qs, e);
}
const Js = /* @__PURE__ */ u("ZodBoolean", (e, t) => {
  Jn.init(e, t), M.init(e, t);
});
function ae(e) {
  return jo(Js, e);
}
const Ws = /* @__PURE__ */ u("ZodUnknown", (e, t) => {
  Wn.init(e, t), M.init(e, t);
});
function Me() {
  return Uo(Ws);
}
const Vs = /* @__PURE__ */ u("ZodNever", (e, t) => {
  Vn.init(e, t), M.init(e, t);
});
function Gs(e) {
  return qo(Vs, e);
}
const Hs = /* @__PURE__ */ u("ZodArray", (e, t) => {
  Gn.init(e, t), M.init(e, t), e.element = t.element, e.min = (r, n) => e.check(Oe(r, n)), e.nonempty = (r) => e.check(Oe(1, r)), e.max = (r, n) => e.check(Wt(r, n)), e.length = (r, n) => e.check(Vt(r, n)), e.unwrap = () => e.element;
});
function he(e, t) {
  return ts(Hs, e, t);
}
const Ks = /* @__PURE__ */ u("ZodObject", (e, t) => {
  Kn.init(e, t), M.init(e, t), $(e, "shape", () => t.shape), e.keyof = () => Pe(Object.keys(e._zod.def.shape)), e.catchall = (r) => e.clone({ ...e._zod.def, catchall: r }), e.passthrough = () => e.clone({ ...e._zod.def, catchall: Me() }), e.loose = () => e.clone({ ...e._zod.def, catchall: Me() }), e.strict = () => e.clone({ ...e._zod.def, catchall: Gs() }), e.strip = () => e.clone({ ...e._zod.def, catchall: void 0 }), e.extend = (r) => fr(e, r), e.safeExtend = (r) => hr(e, r), e.merge = (r) => pr(e, r), e.pick = (r) => dr(e, r), e.omit = (r) => mr(e, r), e.partial = (...r) => wr(Kt, e, r[0]), e.required = (...r) => br(Yt, e, r[0]);
});
function K(e, t) {
  const r = {
    type: "object",
    get shape() {
      return ne(this, "shape", e ? ir(e) : {}), this.shape;
    },
    ...d(t)
  };
  return new Ks(r);
}
const Ys = /* @__PURE__ */ u("ZodUnion", (e, t) => {
  Yn.init(e, t), M.init(e, t), e.options = t.options;
});
function Xs(e, t) {
  return new Ys({
    type: "union",
    options: e,
    ...d(t)
  });
}
const Qs = /* @__PURE__ */ u("ZodIntersection", (e, t) => {
  Xn.init(e, t), M.init(e, t);
});
function ea(e, t) {
  return new Qs({
    type: "intersection",
    left: e,
    right: t
  });
}
const ta = /* @__PURE__ */ u("ZodRecord", (e, t) => {
  Qn.init(e, t), M.init(e, t), e.keyType = t.keyType, e.valueType = t.valueType;
});
function me(e, t, r) {
  return new ta({
    type: "record",
    keyType: e,
    valueType: t,
    ...d(r)
  });
}
const We = /* @__PURE__ */ u("ZodEnum", (e, t) => {
  eo.init(e, t), M.init(e, t), e.enum = t.entries, e.options = Object.values(t.entries);
  const r = new Set(Object.keys(t.entries));
  e.extract = (n, o) => {
    const s = {};
    for (const a of n)
      if (r.has(a))
        s[a] = t.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new We({
      ...t,
      checks: [],
      ...d(o),
      entries: s
    });
  }, e.exclude = (n, o) => {
    const s = { ...t.entries };
    for (const a of n)
      if (r.has(a))
        delete s[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new We({
      ...t,
      checks: [],
      ...d(o),
      entries: s
    });
  };
});
function Pe(e, t) {
  const r = Array.isArray(e) ? Object.fromEntries(e.map((n) => [n, n])) : e;
  return new We({
    type: "enum",
    entries: r,
    ...d(t)
  });
}
const ra = /* @__PURE__ */ u("ZodTransform", (e, t) => {
  to.init(e, t), M.init(e, t), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Tt(e.constructor.name);
    r.addIssue = (s) => {
      if (typeof s == "string")
        r.issues.push(Ae(s, r.value, t));
      else {
        const a = s;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), a.input ?? (a.input = r.value), a.inst ?? (a.inst = e), r.issues.push(Ae(a));
      }
    };
    const o = t.transform(r.value, r);
    return o instanceof Promise ? o.then((s) => (r.value = s, r)) : (r.value = o, r);
  };
});
function na(e) {
  return new ra({
    type: "transform",
    transform: e
  });
}
const Kt = /* @__PURE__ */ u("ZodOptional", (e, t) => {
  ro.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType;
});
function It(e) {
  return new Kt({
    type: "optional",
    innerType: e
  });
}
const oa = /* @__PURE__ */ u("ZodNullable", (e, t) => {
  no.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType;
});
function xt(e) {
  return new oa({
    type: "nullable",
    innerType: e
  });
}
const sa = /* @__PURE__ */ u("ZodDefault", (e, t) => {
  oo.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function aa(e, t) {
  return new sa({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Ot(t);
    }
  });
}
const ia = /* @__PURE__ */ u("ZodPrefault", (e, t) => {
  so.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType;
});
function ca(e, t) {
  return new ia({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Ot(t);
    }
  });
}
const Yt = /* @__PURE__ */ u("ZodNonOptional", (e, t) => {
  ao.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType;
});
function ua(e, t) {
  return new Yt({
    type: "nonoptional",
    innerType: e,
    ...d(t)
  });
}
const la = /* @__PURE__ */ u("ZodCatch", (e, t) => {
  io.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function ga(e, t) {
  return new la({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
const da = /* @__PURE__ */ u("ZodPipe", (e, t) => {
  co.init(e, t), M.init(e, t), e.in = t.in, e.out = t.out;
});
function $t(e, t) {
  return new da({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
const ma = /* @__PURE__ */ u("ZodReadonly", (e, t) => {
  uo.init(e, t), M.init(e, t), e.unwrap = () => e._zod.def.innerType;
});
function fa(e) {
  return new ma({
    type: "readonly",
    innerType: e
  });
}
const ha = /* @__PURE__ */ u("ZodCustom", (e, t) => {
  lo.init(e, t), M.init(e, t);
});
function pa(e, t = {}) {
  return rs(ha, e, t);
}
function wa(e) {
  return ns(e);
}
class ba {
  static toMinutesOfDay({ hour: t, minute: r }) {
    return t * 60 + r;
  }
}
class ee {
  constructor(t, r) {
    V(this, "hour");
    V(this, "minute");
    if (!Number.isInteger(t) || t < 0 || t > 23)
      throw new RangeError("Hour must be 0–23");
    if (!Number.isInteger(r) || r < 0 || r > 59)
      throw new RangeError("Minute must be 0–59");
    this.hour = t, this.minute = r;
  }
  static of(t, r) {
    return new ee(t, r);
  }
  static now() {
    const t = /* @__PURE__ */ new Date();
    return new ee(t.getHours(), t.getMinutes());
  }
  static parse(t) {
    const r = /^(\d{2}):(\d{2})$/.exec(t);
    if (!r)
      throw new Error("Invalid time string: " + t);
    const [, n, o] = r;
    return new ee(+n, +o);
  }
  toString() {
    const t = (r) => String(r).padStart(2, "0");
    return `${t(this.hour)}:${t(this.minute)}`;
  }
  toMinutesOfDay() {
    return ba.toMinutesOfDay(this);
  }
  compareTo(t) {
    return this.toMinutesOfDay() - t.toMinutesOfDay();
  }
  plusMinutes(t) {
    const r = (this.toMinutesOfDay() + t + 1440) % 1440, n = Math.floor(r / 60), o = r % 60;
    return new ee(n, o);
  }
}
const pe = {
  BUY_OFFER: "buy-offer",
  EMAIL: "email",
  ITEM: "item",
  MY_OFFER: "my-offer",
  INBOX: "inbox"
}, Et = K({
  hour: x().int().min(0).max(23),
  minute: x().int().min(0).max(59)
}).transform(({ hour: e, minute: t }) => ee.of(e, t)), _a = me(Pe(["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]), K({
  enabled: ae(),
  min: Et,
  max: Et
})), Xt = K({
  min: x(),
  max: x()
}), Aa = K({
  insuredType: D().optional(),
  insuredAge: Xt.optional(),
  meta: me(D(), Me()).optional()
}), va = K({
  text: D(),
  insuredType: D(),
  insuredAge: Xt,
  meta: me(D(), Me()).optional()
}), rt = K({
  id: D(),
  name: D(),
  patterns: he(Aa)
}), ya = rt, ka = K({
  // Inbox mode configuration
  inboxMode: ae().default(!0),
  inboxReloadSeconds: he(x()).default([4, 7]),
  inboxPostReloadDelayMs: x().default(0),
  inboxMaxLinksPerScan: x().default(10),
  inboxInterOpenDelayMs: x().default(400),
  token: D().optional(),
  // Required fields (removed .optional())
  operationalHours: _a,
  emailMode: ae(),
  emailRefreshMin: x(),
  emailRefreshMax: x(),
  products: he(va),
  // Animal insurance product strategy
  animals: ae(),
  animalTimerMin: x(),
  animalTimerMax: x(),
  animalProcessingTimeSeconds: x(),
  // Cancer scan product strategy
  cancer: ae(),
  cancerTimerMin: x(),
  cancerTimerMax: x(),
  cancerProcessingTimeSeconds: x(),
  // People insurance product strategy
  people: ae(),
  peopleTimerMin: x(),
  peopleTimerMax: x(),
  peopleProcessingTimeSeconds: x()
}), ze = K({
  id: D(),
  timeout: x()
}), Ve = K({
  timestamp: x(),
  message: D()
}), Ia = K({
  id: D(),
  timestamp: x(),
  requestTimestamp: x(),
  status: Pe(["running", "done", "failed"]),
  source: Pe(["email", "inbox"]),
  doneTimestamp: x().optional()
}), Ge = K({
  flowId: D(),
  createdAt: x(),
  lastActive: x()
}), Z = K({
  enabled: ae(),
  config: ka,
  logs: he(Ve),
  managedTabs: me(D(), Ge),
  buyingOffers: me(D(), ze),
  productStrategies: he(rt),
  flows: me(D(), Ia)
});
function k(e, t) {
  return e.parse(t);
}
const se = {
  enabled: !1,
  min: ee.of(8, 0),
  max: ee.of(17, 0)
}, Qt = {
  enabled: !0,
  config: {
    operationalHours: {
      Sunday: { ...se, enabled: !0 },
      Monday: { ...se, enabled: !0 },
      Tuesday: { ...se, enabled: !0 },
      Wednesday: { ...se, enabled: !0 },
      Thursday: { ...se, enabled: !0 },
      Friday: { ...se, enabled: !0 },
      Saturday: { ...se, enabled: !0 }
    },
    emailMode: !1,
    emailRefreshMin: 30,
    emailRefreshMax: 60,
    products: [],
    // Inbox mode defaults
    inboxMode: !0,
    inboxReloadSeconds: [4, 7],
    inboxPostReloadDelayMs: 0,
    inboxMaxLinksPerScan: 10,
    inboxInterOpenDelayMs: 400,
    // Product strategies
    animals: !0,
    animalTimerMin: 30,
    animalTimerMax: 60,
    animalProcessingTimeSeconds: 0,
    cancer: !0,
    cancerTimerMin: 30,
    cancerTimerMax: 60,
    cancerProcessingTimeSeconds: 0,
    people: !0,
    peopleTimerMin: 30,
    peopleTimerMax: 60,
    peopleProcessingTimeSeconds: 0
  },
  // Initialize empty storage collections
  logs: [],
  managedTabs: {},
  buyingOffers: {},
  productStrategies: [],
  flows: {}
}, w = or("extension-config-storage-key", Qt, {
  storageEnum: _e.Local
}), E = {
  ...w,
  // Flow management namespace
  flows: {
    async cleanupOldFlows() {
      const e = Date.now() - 864e5, t = [];
      await w.set((r) => {
        const n = { ...r.flows };
        for (const [o, s] of Object.entries(n))
          s.timestamp < e && (t.push(o), delete n[o]);
        return k(Z, {
          ...r,
          flows: n
        });
      }), t.length > 0 && await E.logs.addLog(`[Flow] Cleaned up ${t.length} old flows: ${t.join(", ")}`);
    },
    async startFlow(e) {
      return (await w.get()).flows[e.id] ? !0 : (await w.set((r) => k(Z, {
        ...r,
        flows: {
          ...r.flows,
          [e.id]: e
        }
      })), !1);
    },
    async doneFlow(e) {
      await w.set((t) => {
        const r = t.flows[e];
        return r ? k(Z, {
          ...t,
          flows: {
            ...t.flows,
            [e]: { ...r, status: "done", doneTimestamp: Date.now() }
          }
        }) : t;
      });
    },
    async failedFlow(e) {
      await w.set((t) => {
        const r = t.flows[e];
        return r ? k(Z, {
          ...t,
          flows: {
            ...t.flows,
            [e]: { ...r, status: "failed", doneTimestamp: Date.now() }
          }
        }) : t;
      });
    },
    async getFlow(e) {
      return (await w.get()).flows[e];
    },
    async getAllFlowIds() {
      const e = await w.get();
      return Object.keys(e.flows);
    },
    async getAllFlows() {
      const e = await w.get();
      return Object.values(e.flows);
    }
  },
  // Core methods
  toggleEnabled: async () => {
    await w.set((e) => k(Z, {
      ...e,
      enabled: !e.enabled
    }));
  },
  updateConfig: async (e) => {
    await w.set((t) => k(Z, {
      ...t,
      config: {
        ...t.config,
        ...e
      }
    }));
  },
  // Buying state namespace
  buyingState: {
    async markBuying(e, t) {
      const r = k(ze, { id: e, timeout: t });
      await w.set((n) => k(Z, {
        ...n,
        buyingOffers: {
          ...n.buyingOffers,
          [e]: r
        }
      }));
    },
    async checkBuying(e) {
      const r = (await w.get()).buyingOffers[e];
      if (!r)
        return { buying: !1 };
      const n = k(ze, r);
      return Date.now() > n.timeout ? (await this.clearBuying(e), { buying: !1 }) : { buying: !0 };
    },
    async clearBuying(e) {
      await w.set((t) => {
        const { [e]: r, ...n } = t.buyingOffers;
        return k(Z, {
          ...t,
          buyingOffers: n
        });
      });
    },
    async purgeBuying(e) {
      await w.set((t) => {
        const { [e]: r, ...n } = t.buyingOffers;
        return k(Z, {
          ...t,
          buyingOffers: n
        });
      });
    },
    async clearExpired() {
      await w.get();
      const e = Date.now();
      await w.set((t) => {
        const r = Object.entries(t.buyingOffers).filter(([n, o]) => o.timeout > e).reduce((n, [o, s]) => ({ ...n, [o]: s }), {});
        return k(Z, {
          ...t,
          buyingOffers: r
        });
      });
    },
    async getBuyingOffer(e) {
      const r = (await w.get()).buyingOffers[e];
      return r ? k(ze, r) : void 0;
    }
  },
  // Tab management namespace
  tabManagement: {
    async markManaged(e, t) {
      const r = Date.now(), n = k(Ge, {
        flowId: t,
        createdAt: r,
        lastActive: r
      });
      await w.set((o) => k(Z, {
        ...o,
        managedTabs: {
          ...o.managedTabs,
          [e]: n
        }
      }));
    },
    async unmarkManaged(e) {
      await w.set((t) => {
        const { [e]: r, ...n } = t.managedTabs;
        return k(Z, {
          ...t,
          managedTabs: n
        });
      });
    },
    async updateActivity(e) {
      await w.set((t) => {
        const r = t.managedTabs[e];
        if (r) {
          const n = k(Ge, {
            ...r,
            lastActive: Date.now()
          });
          return k(Z, {
            ...t,
            managedTabs: {
              ...t.managedTabs,
              [e]: n
            }
          });
        }
        return t;
      });
    },
    async isManaged(e) {
      const t = await w.get();
      return String(e) in t.managedTabs;
    },
    async getAllManagedTabs() {
      const e = await w.get();
      return Object.keys(e.managedTabs).map(Number);
    },
    async getTabCount() {
      const e = await w.get();
      return Object.keys(e.managedTabs).length;
    },
    async getTabsByFlow(e) {
      const t = await w.get();
      return Object.entries(t.managedTabs).filter(([r, n]) => n.flowId === e).map(([r]) => Number(r));
    },
    async closeAllTabsForFlow(e) {
      const t = await w.get(), r = Object.entries(t.managedTabs).filter(([n, o]) => o.flowId === e).map(([n]) => Number(n));
      for (const n of r)
        try {
          await chrome.tabs.remove(n);
        } catch {
        }
      await w.set((n) => {
        const o = { ...n.managedTabs };
        return r.forEach((s) => {
          delete o[String(s)];
        }), k(Z, {
          ...n,
          managedTabs: o
        });
      });
    },
    async cleanupStaleTabs(e = 5 * 60 * 1e3) {
      const t = await w.get(), r = Date.now(), n = [];
      Object.entries(t.managedTabs).forEach(([o, s]) => {
        r - s.lastActive > e && n.push(Number(o));
      });
      for (const o of n)
        try {
          await chrome.tabs.remove(o);
        } catch {
        }
      return n.length > 0 && await w.set((o) => {
        const s = { ...o.managedTabs };
        return n.forEach((a) => {
          delete s[String(a)];
        }), k(Z, {
          ...o,
          managedTabs: s
        });
      }), n.length;
    },
    async validateExistingTabs() {
      const e = await w.get(), t = Object.keys(e.managedTabs).map(Number), r = [];
      for (const n of t)
        try {
          await chrome.tabs.get(n);
        } catch {
          r.push(n);
        }
      return r.length > 0 && await w.set((n) => {
        const o = { ...n.managedTabs };
        return r.forEach((s) => {
          delete o[String(s)];
        }), k(Z, {
          ...n,
          managedTabs: o
        });
      }), r.length;
    }
  },
  // Logs namespace
  logs: {
    async addLog(e) {
      const t = k(Ve, {
        timestamp: Date.now(),
        message: e
      });
      await w.set((r) => k(Z, {
        ...r,
        logs: [...r.logs, t]
      }));
    },
    async getLogs() {
      return (await w.get()).logs.map((t) => k(Ve, t));
    },
    async clearLogs() {
      await w.set((e) => k(Z, {
        ...e,
        logs: []
      }));
    }
  },
  // Product strategies namespace
  productStrategies: {
    async get() {
      return (await w.get()).productStrategies.map((t) => k(ya, t));
    },
    async set(e) {
      const r = e.map((n) => ({
        id: n.id,
        name: n.name,
        patterns: n.patterns
      })).map((n) => k(rt, n));
      await w.set((n) => k(Z, {
        ...n,
        productStrategies: r
      }));
    },
    async clear() {
      await w.set((e) => k(Z, {
        ...e,
        productStrategies: []
      }));
    }
  },
  // Actions methods
  async restoreDefaults() {
    await w.set(() => k(Z, Qt));
  },
  async clearFlowDatabase() {
    const e = (await w.get()).flows;
    for (const [t, r] of Object.entries(e))
      await chrome.runtime.sendMessage({
        type: "state.buying",
        payload: {
          action: "purge",
          flowId: t
        }
      });
    await w.set((t) => k(Z, {
      ...t,
      flows: {},
      logs: []
    }));
  }
};
class P {
  /**
   * Initialize configuration with defaults
   */
  static async init() {
    try {
      const t = await E.get();
      console.log("[Config] Configuration checked");
    } catch (t) {
      throw console.error("[Config] Error initializing configuration:", t), t;
    }
  }
  /**
   * Get current configuration
   */
  static async getConfig() {
    return (await E.get()).config;
  }
  /**
   * Update configuration
   */
  static async updateConfig(t) {
    await E.updateConfig(t);
  }
  /**
   * Check if extension is enabled
   */
  static async isEnabled() {
    return (await E.get()).enabled;
  }
  /**
   * Set extension enabled state
   */
  static async toggleEnabled() {
    await E.toggleEnabled();
  }
  /**
   * Get product strategies
   */
  static async getProductStrategies() {
    return E.productStrategies.get();
  }
  /**
   * Update product strategies
   */
  static async setProductStrategies(t) {
    await E.productStrategies.set(t);
  }
  /**
   * Start a new flow or check if it already exists
   * @returns true if flow already exists, false if newly added
   */
  static async startFlow(t) {
    const r = await E.flows.startFlow(t);
    return await E.logs.addLog(r ? `[Flow] Skipped existing flow ${t.id} (${t.source})` : `[Flow] Started new flow ${t.id} (${t.source})`), r;
  }
  /**
   * Get flow by ID
   */
  static async getFlow(t) {
    return E.flows.getFlow(t);
  }
  /**
   * Get all flows
   */
  static async getAllFlows() {
    return E.flows.getAllFlows();
  }
  /**
   * Mark a flow as done
   */
  static async doneFlow(t) {
    await E.flows.doneFlow(t), await E.logs.addLog(`[Flow] Marked flow ${t} as done`);
  }
  /**
   * Mark a flow as done
   */
  static async failedFlow(t) {
    await E.flows.failedFlow(t), await E.logs.addLog(`[Flow] Marked flow ${t} as failed`);
  }
}
class xa {
  constructor(t) {
    V(this, "storage");
    this.storage = t;
  }
  async openTab(t, r = !1, n) {
    const o = await chrome.tabs.create({ url: t });
    return r && o.id && n && await this.storage.tabManagement.markManaged(o.id, n), o;
  }
  async closeTab(t) {
    await chrome.tabs.remove(t), await this.storage.tabManagement.unmarkManaged(t);
  }
  async reloadTab(t) {
    await chrome.tabs.reload(t);
  }
  async isManaged(t) {
    return this.storage.tabManagement.isManaged(t);
  }
  async markManaged(t, r) {
    await this.storage.tabManagement.markManaged(t, r);
  }
  async unmarkManaged(t) {
    await this.storage.tabManagement.unmarkManaged(t);
  }
  async getManagedTabs() {
    return this.storage.tabManagement.getAllManagedTabs();
  }
  async updateActivity(t) {
    await this.storage.tabManagement.updateActivity(t);
  }
  async getTabCount() {
    return this.storage.tabManagement.getTabCount();
  }
  async closeAllTabsForFlow(t) {
    await this.storage.tabManagement.closeAllTabsForFlow(t);
  }
  async cleanupStaleTabs() {
    return this.storage.tabManagement.cleanupStaleTabs(5 * 60 * 1e3);
  }
  async validateExistingTabs() {
    return this.storage.tabManagement.validateExistingTabs();
  }
}
class $a {
  constructor(t) {
    V(this, "storage");
    this.storage = t;
  }
  async markBuying(t, r) {
    await this.storage.buyingState.markBuying(t, r);
  }
  async isBuying(t) {
    return this.storage.buyingState.checkBuying(t);
  }
  async clearExpired() {
    await this.storage.buyingState.clearExpired();
  }
  async getBuyingOffer(t) {
    return this.storage.buyingState.getBuyingOffer(t);
  }
  async clearBuying(t) {
    await this.storage.buyingState.clearBuying(t);
  }
  async purgeBuying(t) {
    await this.storage.buyingState.purgeBuying(t);
  }
}
const ie = class ie {
  constructor() {
    V(this, "storage", {
      entries: /* @__PURE__ */ new Map(),
      flowIndex: /* @__PURE__ */ new Map(),
      matcherIndex: /* @__PURE__ */ new Map()
    });
  }
  static getInstance() {
    return ie.instance || (ie.instance = new ie()), ie.instance;
  }
  generateId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
  addEntry(t) {
    const r = this.generateId(), n = { ...t, id: r }, o = Math.floor(t.timestamp / 6e4).toString(), s = this.storage.entries.get(o) || [];
    if (s.push(n), this.storage.entries.set(o, s), t.flowId) {
      const i = this.storage.flowIndex.get(t.flowId) || [];
      i.push(r), this.storage.flowIndex.set(t.flowId, i);
    }
    const a = this.storage.matcherIndex.get(t.matcherId) || [];
    return a.push(r), this.storage.matcherIndex.set(t.matcherId, a), r;
  }
  getEntry(t) {
    for (const [, r] of this.storage.entries) {
      const n = r.find((o) => o.id === t);
      if (n)
        return n;
    }
  }
  getAllLogs() {
    const t = [];
    for (const [, r] of this.storage.entries)
      t.push(...r);
    return t.sort((r, n) => r.timestamp - n.timestamp);
  }
  getLogsByFlowId(t) {
    return (this.storage.flowIndex.get(t) || []).map((n) => this.getEntry(n)).filter((n) => n !== void 0).sort((n, o) => n.timestamp - o.timestamp);
  }
  getLogsByMatcherId(t) {
    return (this.storage.matcherIndex.get(t) || []).map((n) => this.getEntry(n)).filter((n) => n !== void 0).sort((n, o) => n.timestamp - o.timestamp);
  }
  clearAllLogs() {
    this.storage.entries.clear();
  }
  clearOldLogs(t = 36e5) {
    const r = Date.now() - t, n = Math.floor(r / 6e4).toString();
    for (const [o] of this.storage.entries)
      o < n && ((this.storage.entries.get(o) || []).forEach((a) => {
        if (a.flowId) {
          const g = (this.storage.flowIndex.get(a.flowId) || []).filter((m) => m !== a.id);
          g.length > 0 ? this.storage.flowIndex.set(a.flowId, g) : this.storage.flowIndex.delete(a.flowId);
        }
        const c = (this.storage.matcherIndex.get(a.matcherId) || []).filter((l) => l !== a.id);
        c.length > 0 ? this.storage.matcherIndex.set(a.matcherId, c) : this.storage.matcherIndex.delete(a.matcherId);
      }), this.storage.entries.delete(o));
  }
  exportLogs() {
    return JSON.stringify(this.getAllLogs(), null, 2);
  }
};
V(ie, "instance");
let G = ie;
class Ce {
  constructor(t, r) {
    V(this, "matcherId");
    V(this, "flowId");
    V(this, "messages", []);
    V(this, "metadata", {});
    V(this, "logManager", G.getInstance());
    this.matcherId = t, this.flowId = r;
  }
  static withFlow(t, r) {
    return new Ce(t, r);
  }
  info(t, r) {
    return this.addMessage("info", t, r), this;
  }
  warn(t, r) {
    return this.addMessage("warn", t, r), this;
  }
  error(t, r) {
    return this.addMessage("error", t, r), this;
  }
  debug(t, r) {
    return this.addMessage("debug", t, r), this;
  }
  // Backward compatibility with existing push method
  push(t) {
    return this.info(t);
  }
  addMessage(t, r, n) {
    const o = Date.now();
    this.messages.push({ message: r, timestamp: o, level: t }), this.logManager.addEntry({
      timestamp: o,
      matcherId: this.matcherId,
      flowId: this.flowId,
      level: t,
      message: r,
      metadata: { ...this.metadata, ...n }
    });
    function s(i = /* @__PURE__ */ new Date()) {
      const c = (F, A = 2) => String(F).padStart(A, "0"), l = i.getFullYear(), g = c(i.getMonth() + 1), m = c(i.getDate()), b = c(i.getHours()), h = c(i.getMinutes()), y = c(i.getSeconds()), O = c(i.getMilliseconds(), 3);
      return `${l}-${g}-${m} ${b}:${h}:${y}.${O}`;
    }
    const a = `[${s()}][${this.matcherId}]${this.flowId ? `[${this.flowId}]` : ""}`;
    switch (t) {
      case "error":
        console.error(`${a} ${r}`, n || "");
        break;
      case "warn":
        console.warn(`${a} ${r}`, n || "");
        break;
      case "debug":
        console.debug(`${a} ${r}`, n || "");
        break;
      default:
        console.log(`${a} ${r}`, n || "");
    }
  }
  setMetadata(t) {
    return this.metadata = { ...this.metadata, ...t }, this;
  }
  async write() {
    var t;
    if (this.messages.length > 0 && typeof window < "u")
      try {
        (t = chrome == null ? void 0 : chrome.runtime) != null && t.sendMessage && await chrome.runtime.sendMessage({
          type: "extension.log",
          payload: {
            matcherId: this.matcherId,
            flowId: this.flowId,
            messages: this.messages,
            metadata: this.metadata,
            timestamp: Date.now()
          }
        });
      } catch (r) {
        console.error("Failed to send log to background:", r);
      }
  }
  // Static methods for querying logs
  static getAllLogs() {
    return G.getInstance().getAllLogs();
  }
  static getFlowLogs(t) {
    return G.getInstance().getLogsByFlowId(t);
  }
  static getMatcherLogs(t) {
    return G.getInstance().getLogsByMatcherId(t);
  }
  static exportFlowTimeline(t) {
    const n = G.getInstance().getLogsByFlowId(t).sort((o, s) => o.timestamp - s.timestamp).map((o) => `${new Date(o.timestamp).toISOString()} [${o.level.toUpperCase()}] [${o.matcherId}] ${o.message}`).join(`
`);
    return `Flow Timeline: ${t}
${"=".repeat(50)}
${n}`;
  }
  static cleanupOldLogs(t) {
    G.getInstance().clearOldLogs(t);
  }
  /**
   * Query logs from background script
   * These methods work in background context or via message passing
   */
  static async queryLogs(t) {
    var r, n;
    if (typeof chrome < "u" && !((r = chrome.runtime) != null && r.sendMessage)) {
      const o = G.getInstance();
      switch (t.action) {
        case "getAllLogs":
          return o.getAllLogs();
        case "getFlowLogs":
          return o.getLogsByFlowId(t.flowId);
        case "getMatcherLogs":
          return o.getLogsByMatcherId(t.matcherId);
        case "exportFlowTimeline":
          return Ce.exportFlowTimeline(t.flowId);
        default:
          throw new Error(`Unknown action: ${t.action}`);
      }
    }
    if ((n = chrome == null ? void 0 : chrome.runtime) != null && n.sendMessage) {
      const o = await chrome.runtime.sendMessage({
        type: "logs.query",
        payload: t
      });
      if (o.success)
        return o.data;
      throw new Error(o.error);
    }
    return G.getInstance().getAllLogs();
  }
  /**
   * Get log statistics (works from any context)
   */
  static async getStats() {
    var t;
    if (typeof chrome < "u" && ((t = chrome.runtime) != null && t.sendMessage)) {
      const r = await chrome.runtime.sendMessage({
        type: "logs.stats",
        payload: {}
      });
      if (r.success)
        return r.data;
    }
    return {
      totalLogs: 0,
      logsByLevel: {},
      logsByMatcher: {},
      oldestLog: null,
      newestLog: null
    };
  }
}
class zt {
  static parseDateToEpoch(t) {
    const r = t.replace("–", "-").trim(), [n, o] = r.split("-").map((j) => j.trim());
    if (!n || !o)
      throw new Error(`Invalid date string format: ${t}`);
    const [s, a, i] = n.split("."), c = parseInt(s, 10), l = parseInt(a, 10), g = parseInt(i, 10), [m, b, h] = o.split(":"), y = parseInt(m, 10), O = parseInt(b, 10), F = parseInt(h, 10), A = new Date(g, l - 1, c, y, O, F);
    if (isNaN(A.getTime()))
      throw new Error(`Failed to parse date: ${t}`);
    return A.getTime();
  }
  static parseIDFromTitle(t) {
    const r = /\(ID\s+(\d+)\)/.exec(t);
    if (r)
      return r[1];
    const n = /Lead\s+(\d+)/.exec(t);
    if (n)
      return n[1];
    throw new Error("Could not parse ID from title");
  }
  static parseIDFromHref(t) {
    const n = new URL(t).searchParams.get("id");
    if (!n)
      throw new Error("No ID parameter in URL");
    return n;
  }
  static parseIDFromPath(t) {
    const r = /\/id\/(\d+)\.html/.exec(t);
    if (!r)
      throw new Error("Could not parse ID from path");
    return r[1];
  }
  static email(t) {
    const r = Date.now();
    return {
      id: t,
      timestamp: r,
      requestTimestamp: r,
      status: "running",
      source: "email"
    };
  }
  static inbox(t, r) {
    return {
      id: t,
      timestamp: Date.now(),
      requestTimestamp: r,
      status: "running",
      source: "inbox"
    };
  }
}
const Ea = async (e) => new Promise((t) => setTimeout(t, e)), za = async (e, t) => {
  var r, n, o;
  console.log("[Background] Buy offer command received from tab:", (r = t.tab) == null ? void 0 : r.id);
  try {
    if (!((n = t.tab) != null && n.id))
      throw new Error("No tab ID in sender");
    const s = t.tab.id, [a, i] = await Promise.all([P.getConfig(), P.isEnabled()]);
    if (!i)
      return {
        success: !1,
        error: "Extension is disabled",
        requestId: e.id
      };
    const c = await P.getFlow(e.id);
    if (!c)
      return {
        success: !1,
        error: "Flow not found",
        requestId: e.id
      };
    const l = {
      tabId: s,
      url: t.tab.url || "",
      matcherId: pe.BUY_OFFER,
      config: a,
      timeout: 6e4,
      // 60 seconds timeout due to delay
      dryRun: !1
    }, m = (o = (await chrome.scripting.executeScript({
      target: { tabId: s },
      func: async (b, h, y) => {
        const O = JSON.parse(b), F = JSON.parse(h), A = JSON.parse(y);
        if (typeof window.__buyOfferExecutor == "function")
          try {
            return await window.__buyOfferExecutor(O, F, A);
          } catch (j) {
            console.error("[Background] Buy offer workflow error:", j);
          }
        return {
          success: !1,
          error: "Buy offer executor not loaded",
          matcherId: O.matcherId,
          executorName: "buyOffer"
        };
      },
      args: [
        JSON.stringify(l),
        JSON.stringify(e.selectors),
        JSON.stringify(c)
      ]
    }))[0]) == null ? void 0 : o.result;
    if (!m)
      throw new Error("No result from buy offer executor");
    return m.success ? console.log("[Background] Buy offer workflow completed successfully:", m.data) : console.error("[Background] Buy offer workflow failed:", m.error), {
      success: m.success,
      data: m,
      error: m.error,
      requestId: e.id
    };
  } catch (s) {
    return console.error("[Background] Error handling buy offer command:", s), {
      success: !1,
      error: s instanceof Error ? s.message : "Unknown error",
      requestId: e.id
    };
  }
}, Ta = async (e, t) => {
  var r, n, o;
  console.log("[Background] Email command received from tab:", (r = t.tab) == null ? void 0 : r.id);
  try {
    if (!((n = t.tab) != null && n.id))
      throw new Error("No tab ID in sender");
    const s = t.tab.id, [a, i] = await Promise.all([P.getConfig(), P.isEnabled()]);
    if (!i)
      return {
        success: !1,
        error: "Extension is disabled",
        requestId: `email-${Date.now()}`
      };
    const c = {
      tabId: s,
      url: t.tab.url || "",
      matcherId: pe.EMAIL,
      config: a,
      timeout: 3e4,
      // 30 seconds timeout
      dryRun: !1
    }, g = (o = (await chrome.scripting.executeScript({
      target: { tabId: s },
      func: async (m, b) => {
        const h = JSON.parse(m), y = JSON.parse(b);
        return typeof window.__emailExecutor == "function" ? await window.__emailExecutor(h, y) : {
          success: !1,
          error: "Email executor not loaded",
          matcherId: h.matcherId,
          executorName: "email"
        };
      },
      args: [
        JSON.stringify(c),
        JSON.stringify(
          e.selectors || {
            unreadEmail: '[aria-label^="Ungelesen HanseMerkur AuktionsPlattform"]',
            emailBody: "#x_body a",
            markAsReadButton: "span"
          }
        )
      ]
    }))[0]) == null ? void 0 : o.result;
    if (!g)
      throw new Error("No result from email executor");
    return g.success ? console.log("[Background] Email workflow completed successfully:", g.data) : console.error("[Background] Email workflow failed:", g.error), {
      success: g.success,
      data: g,
      error: g.error,
      requestId: `email-${Date.now()}`
    };
  } catch (s) {
    return console.error("[Background] Error handling email command:", s), {
      success: !1,
      error: s instanceof Error ? s.message : "Unknown error",
      requestId: `email-${Date.now()}`
    };
  }
}, Za = async (e, t) => {
  var n, o;
  console.log("[Background] Inbox command received from tab:", (n = t.tab) == null ? void 0 : n.id);
  const r = new Ce(pe.INBOX);
  try {
    if (!((o = t.tab) != null && o.id))
      throw new Error("No tab ID in sender");
    const s = t.tab.id, [a, i] = await Promise.all([P.getConfig(), P.isEnabled()]);
    if (!i || !a.inboxMode)
      return {
        success: !1,
        error: "Inbox mode is disabled",
        requestId: `inbox-${Date.now()}`
      };
    const c = {
      tabId: s,
      url: t.tab.url || "",
      matcherId: pe.INBOX,
      config: a,
      timeout: 3e4
    }, l = await chrome.scripting.executeScript({
      target: { tabId: s },
      func: async (g, m) => {
        const b = JSON.parse(g), h = JSON.parse(m);
        return typeof window.__inboxExecutor == "function" ? await window.__inboxExecutor(b, h) : {
          success: !1,
          error: "Inbox executor not loaded",
          matcherId: b.matcherId,
          executorName: "inbox"
        };
      },
      args: [
        JSON.stringify(c),
        JSON.stringify(e.selectors)
      ]
    });
    return r.info("[Background] Inbox processing complete:", l), await r.write(), {
      success: !0,
      data: {},
      requestId: `inbox-${Date.now()}`
    };
  } catch (s) {
    return r.error(`[Background] Error handling inbox command: ${s}`), await r.write(), {
      success: !1,
      error: s instanceof Error ? s.message : "Unknown error",
      requestId: `inbox-${Date.now()}`
    };
  }
}, Sa = async (e, t) => {
  var r, n, o;
  console.log("[Background] item command received from tab:", (r = t.tab) == null ? void 0 : r.id);
  try {
    if (!((n = t.tab) != null && n.id))
      throw new Error("No tab ID in sender");
    const s = t.tab.id, [a, i] = await Promise.all([P.getConfig(), P.isEnabled()]);
    if (!i)
      return {
        success: !1,
        error: "Extension is disabled",
        requestId: e.id
      };
    const c = await P.getFlow(e.id);
    if (!c)
      return {
        success: !1,
        error: `Flow not found: ${e.id}`,
        requestId: e.id
      };
    const l = {
      tabId: s,
      url: t.tab.url || "",
      matcherId: pe.ITEM,
      config: a,
      timeout: 3e4,
      // 30 seconds timeout
      dryRun: !1
    }, m = (o = (await chrome.scripting.executeScript({
      target: { tabId: s },
      func: async (b, h, y) => {
        const O = JSON.parse(b), F = JSON.parse(h), A = JSON.parse(y);
        return typeof window.__itemExecutor == "function" ? await window.__itemExecutor(O, F, A) : {
          success: !1,
          error: "item executor not loaded",
          matcherId: O.matcherId,
          executorName: "item"
        };
      },
      args: [
        JSON.stringify(l),
        JSON.stringify(e.selectors),
        JSON.stringify(c)
      ]
    }))[0]) == null ? void 0 : o.result;
    if (!m)
      throw new Error("No result from item executor");
    return m.success ? console.log("[Background] item workflow completed successfully:", m.data) : console.error("[Background] item workflow failed:", m.error), {
      success: m.success,
      data: m,
      error: m.error,
      requestId: e.id
    };
  } catch (s) {
    return console.error("[Background] Error handling item command:", s), {
      success: !1,
      error: s instanceof Error ? s.message : "Unknown error",
      requestId: e.id
    };
  }
}, Oa = async (e, t) => {
  var r, n, o;
  console.log("[Background] myOffer command received from tab:", (r = t.tab) == null ? void 0 : r.id);
  try {
    if (!((n = t.tab) != null && n.id))
      throw new Error("No tab ID in sender");
    const s = t.tab.id, [a, i] = await Promise.all([P.getConfig(), P.isEnabled()]);
    if (!i)
      return {
        success: !1,
        error: "Extension is disabled",
        requestId: `myOffer-${Date.now()}`
      };
    const c = {
      tabId: s,
      url: t.tab.url || "",
      matcherId: pe.MY_OFFER,
      config: a,
      timeout: 3e4,
      // 30 seconds timeout
      dryRun: !1
    }, g = (o = (await chrome.scripting.executeScript({
      target: { tabId: s },
      func: async (m, b) => {
        const h = JSON.parse(m), y = JSON.parse(b);
        return typeof window.__myOfferExecutor == "function" ? await window.__myOfferExecutor(h, y) : {
          success: !1,
          error: "myOffer executor not loaded",
          matcherId: h.matcherId,
          executorName: "myOffer"
        };
      },
      args: [
        JSON.stringify(c),
        JSON.stringify(e.selectors)
      ]
    }))[0]) == null ? void 0 : o.result;
    if (!g)
      throw new Error("No result from myOffer executor");
    return g.success ? console.log("[Background] myOffer workflow completed successfully:", g.data) : console.error("[Background] myOffer workflow failed:", g.error), {
      success: g.success,
      data: g,
      error: g.error,
      requestId: e.id
    };
  } catch (s) {
    return console.error("[Background] Error handling myOffer command:", s), {
      success: !1,
      error: s instanceof Error ? s.message : "Unknown error",
      requestId: e.id
    };
  }
}, X = G.getInstance();
class Te {
  /**
   * Process incoming log entries from content scripts
   */
  static handleLogMessage(t) {
    const { matcherId: r, flowId: n, messages: o, metadata: s } = t;
    o.forEach(({ message: a, timestamp: i, level: c }) => {
      X.addEntry({
        timestamp: i,
        matcherId: r,
        flowId: n,
        level: c,
        message: a,
        metadata: s
      });
    }), console.log(`[LoggerService] Stored ${o.length} log entries for ${n || r}`);
  }
  /**
   * Query logs by various criteria
   */
  static queryLogs(t) {
    switch (t.action) {
      case "getAllLogs":
        return X.getAllLogs();
      case "getFlowLogs":
        if (!t.flowId) throw new Error("flowId required for getFlowLogs");
        return X.getLogsByFlowId(t.flowId);
      case "getMatcherLogs":
        if (!t.matcherId) throw new Error("matcherId required for getMatcherLogs");
        return X.getLogsByMatcherId(t.matcherId);
      case "exportFlowTimeline":
        if (!t.flowId) throw new Error("flowId required for exportFlowTimeline");
        const n = X.getLogsByFlowId(t.flowId).sort((o, s) => o.timestamp - s.timestamp).map((o) => `${new Date(o.timestamp).toISOString()} [${o.level.toUpperCase()}] [${o.matcherId}] ${o.message}`).join(`
`);
        return `Flow Timeline: ${t.flowId}
${"=".repeat(50)}
${n}`;
      case "clearOldLogs":
        X.clearOldLogs(t.olderThanMs);
        return;
      case "clearAllLogs":
        this.clearAllLogs();
        return;
      default:
        throw new Error(`Unknown log query action: ${t.action}`);
    }
  }
  /**
   * Get logs for debugging in background console
   */
  static debugLogs(t) {
    if (t) {
      const r = X.getLogsByFlowId(t);
      console.group(`[LoggerService] Flow Logs: ${t}`), r.forEach((n) => {
        const o = new Date(n.timestamp).toISOString();
        console.log(`${o} [${n.level.toUpperCase()}] ${n.message}`, n.metadata || "");
      }), console.groupEnd();
    } else {
      const r = X.getAllLogs();
      console.group("[LoggerService] All Logs"), r.forEach((n) => {
        const o = new Date(n.timestamp).toISOString();
        console.log(
          `${o} [${n.flowId || "no-flow"}] [${n.level.toUpperCase()}] ${n.message}`,
          n.metadata || ""
        );
      }), console.groupEnd();
    }
  }
  /**
   * Export logs to file for debugging
   */
  static exportAllLogs() {
    return JSON.stringify(X.getAllLogs(), null, 2);
  }
  /**
   * Clear all logs from LogManager
   */
  static clearAllLogs() {
    G.getInstance().clearAllLogs(), console.log("[LoggerService] Cleared all logs from LogManager");
  }
  /**
   * Get statistics about stored logs
   */
  static getLogStats() {
    const t = X.getAllLogs(), r = {
      totalLogs: t.length,
      logsByLevel: {},
      logsByMatcher: {},
      oldestLog: null,
      newestLog: null
    };
    if (t.length === 0) return r;
    t.forEach((o) => {
      r.logsByLevel[o.level] = (r.logsByLevel[o.level] || 0) + 1, r.logsByMatcher[o.matcherId] = (r.logsByMatcher[o.matcherId] || 0) + 1;
    });
    const n = t.sort((o, s) => o.timestamp - s.timestamp);
    return r.oldestLog = new Date(n[0].timestamp), r.newestLog = new Date(n[n.length - 1].timestamp), r;
  }
}
typeof globalThis < "u" && (globalThis.LoggerService = Te);
var Ma = { CEB_TRC_BACKEND_URL: "https://trc-platform-bf1b64bd7e59.herokuapp.com" };
const ue = new xa(E), $e = new $a(E);
async function Pa() {
  try {
    await P.init(), console.log("[Background] Configuration initialized"), Ca(), console.log("[Background] Message handlers registered");
  } catch (e) {
    console.error("[Background] Initialization error:", e);
  }
}
function Ca() {
  chrome.runtime.onMessage.addListener(
    (e, t, r) => (Na(e, t).then(r).catch((n) => {
      console.error("[Background] Message handler error:", n), r({
        success: !1,
        error: n instanceof Error ? n.message : "Unknown error",
        requestId: "error"
      });
    }), !0)
  );
}
async function Na(e, t) {
  console.log("[Background] Received message:", e.type);
  try {
    switch (e.type) {
      case "inbox.openMyOfferLink":
        return Za(e.payload, t);
      case "email.openUnreadAndClickLink":
        return Ta(e.payload, t);
      case "item.clickProductLink":
        return Sa(e.payload, t);
      case "myOffer.clickProductLink":
        return Oa(e.payload, t);
      case "buyOffer.execute":
        return za(e.payload, t);
      case "tab.manage":
        return Fa(e.payload, t);
      case "flows.scheduleCloseAfterNavigation":
        return Da(e.payload, t), {
          success: !0,
          requestId: "scheduleCloseAfterNavigation"
        };
      case "state.buying":
        return La(e.payload);
      case "image.solve":
        return Ra(e.payload.imageData, e.payload.flowId).then((n) => (console.log("[Background] Successfully processed image"), { success: !0, data: n, requestId: "image" })).catch((n) => (console.error("[Background] Error processing image:", n), {
          success: !1,
          requestId: "image",
          error: n instanceof Error ? n.message : "Unknown error"
        }));
      case "extension.log":
        return Te.handleLogMessage(e.payload), { success: !0, requestId: "log" };
      case "extension.telemetry":
        const { events: r } = e.payload;
        return r.forEach((n) => {
          console.log(`[Telemetry] ${n.eventName}:`, n);
        }), { success: !0, requestId: "telemetry" };
      case "extension.getConfig":
        return {
          success: !0,
          data: {
            config: await P.getConfig(),
            enabled: await P.isEnabled()
          },
          requestId: "config"
        };
      case "extension.toggleEnabled":
        return await P.toggleEnabled(), { success: !0, requestId: "toggle-enabled" };
      case "extension.startFlow": {
        const n = e.payload, o = n.type === "email" ? zt.email(n.id) : zt.inbox(n.id, n.requestTimestamp);
        return {
          success: !0,
          data: await P.startFlow(o),
          requestId: n.id
        };
      }
      case "extension.getFlow": {
        const { id: n } = e.payload;
        return {
          success: !0,
          data: await P.getFlow(n),
          requestId: n
        };
      }
      case "extension.getAllFlows":
        return {
          success: !0,
          data: await P.getAllFlows(),
          requestId: "get-all-flows"
        };
      case "logs.query":
        try {
          return {
            success: !0,
            data: Te.queryLogs(e.payload),
            requestId: "logs-query"
          };
        } catch (n) {
          return {
            success: !1,
            error: n instanceof Error ? n.message : "Unknown error",
            requestId: "logs-query"
          };
        }
      case "logs.stats":
        return {
          success: !0,
          data: Te.getLogStats(),
          requestId: "logs-stats"
        };
      default:
        throw new Error(`Unknown command type: ${String(e.type)}`);
    }
  } catch (r) {
    throw console.error("[Background] Error handling message:", r), r;
  }
}
async function Fa(e, t) {
  var n;
  const r = "tab";
  try {
    switch (e.action) {
      case "open":
        if (!e.url)
          throw new Error("URL required for open action");
        return {
          success: !0,
          data: { tabId: (await ue.openTab(e.url, !0, e.flowId)).id },
          requestId: r
        };
      case "close":
        const s = e.tabId || ((n = t.tab) == null ? void 0 : n.id);
        if (!s)
          throw new Error("Tab ID required for close action");
        return await ue.closeTab(s), {
          success: !0,
          requestId: r
        };
      case "reload":
        if (!e.tabId)
          throw new Error("Tab ID required for reload action");
        return await ue.reloadTab(e.tabId), {
          success: !0,
          requestId: r
        };
      case "manage":
        if (!e.tabId || !e.flowId)
          throw new Error("Tab ID and Flow ID required for manage action");
        return await ue.markManaged(e.tabId, e.flowId), {
          success: !0,
          requestId: r
        };
      case "unmanage":
        if (!e.tabId)
          throw new Error("Tab ID required for unmanage action");
        return await ue.unmarkManaged(e.tabId), {
          success: !0,
          requestId: r
        };
      case "isManaged":
        if (!e.tabId)
          throw new Error("Tab ID required for isManaged action");
        return {
          success: !0,
          data: { isManaged: await ue.isManaged(e.tabId) },
          requestId: r
        };
      case "addManagedTab":
        if (!e.tabId || !e.flowId)
          throw new Error("Tab ID and Flow ID required for addManagedTab action");
        return await E.tabManagement.markManaged(e.tabId, e.flowId), {
          success: !0,
          requestId: r
        };
      case "updateActivity":
        if (!e.tabId)
          throw new Error("Tab ID required for updateActivity action");
        return await E.tabManagement.updateActivity(e.tabId), {
          success: !0,
          requestId: r
        };
      case "getTabCount":
        return {
          success: !0,
          data: { count: await E.tabManagement.getTabCount() },
          requestId: r
        };
      case "closeAllTabs":
        if (!e.flowId)
          throw new Error("Flow ID required for closeAllTabs action");
        return await E.tabManagement.closeAllTabsForFlow(e.flowId), {
          success: !0,
          requestId: r
        };
      case "cleanupStale":
        return {
          success: !0,
          data: { cleanedCount: await E.tabManagement.cleanupStaleTabs(5 * 60 * 1e3) },
          requestId: r
        };
      default:
        throw new Error(`Unknown tab action: ${e.action}`);
    }
  } catch (o) {
    return console.error("[Background] Tab management error:", o), {
      success: !1,
      error: o instanceof Error ? o.message : "Unknown error",
      requestId: r
    };
  }
}
async function Da(e, t) {
  console.log(`[Background] Closing all tabs for flow: ${e.flowId} after ${e.timeoutMs}ms`), setTimeout(async function() {
    await Ea(e.timeoutMs), console.info(`[Background] Closing all tabs: ${e.flowId}:`), await E.tabManagement.closeAllTabsForFlow(e.flowId);
  }, 0);
}
async function La(e) {
  const t = e.flowId;
  try {
    switch (e.action) {
      case "mark":
        if (!e.timeout)
          throw new Error("Timeout required for mark action");
        return await $e.markBuying(e.flowId, e.timeout), {
          success: !0,
          requestId: t
        };
      case "check":
        return {
          success: !0,
          data: await $e.isBuying(e.flowId),
          requestId: t
        };
      case "clear":
        return await $e.clearBuying(e.flowId), {
          success: !0,
          requestId: t
        };
      case "purge":
        return await $e.purgeBuying(e.flowId), {
          success: !0,
          requestId: t
        };
      default:
        throw new Error(`Unknown buying state action: ${e.action}`);
    }
  } catch (r) {
    return console.error("[Background] Buying state error:", r), {
      success: !1,
      error: r instanceof Error ? r.message : "Unknown error",
      requestId: t
    };
  }
}
Pa();
async function Ra(e, t) {
  const r = Ma.CEB_TRC_BACKEND_URL, n = await P.getConfig();
  if (console.log("[CEB] sending requests to backend:", r), !n.token)
    throw new Error("API token not configured. Please set your API token in the extension options.");
  console.log("[Background] Processing image via API...");
  const s = await (await fetch(e)).blob(), a = new FormData();
  a.append("file", s, "image.png"), a.append("flow_id", t);
  const i = await fetch(`${r}/api/core/solve`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${n.token}`
    },
    body: a
  });
  if (!i.ok) {
    const l = await i.text();
    throw new Error(`API request failed (${i.status}): ${l}`);
  }
  const c = await i.json();
  if (console.log("[Background] API response received:", c), !c.result)
    throw new Error("No result in API response");
  return c;
}
